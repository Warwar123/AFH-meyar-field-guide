import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { ENV } from "./env";
import { getPortalSettings, recordSecurityEvent } from "../db";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

const isConfiguredOwner = async (user: { openId: string; email: string | null }) => { const settings = await getPortalSettings(); const approvedEmail = settings?.approvedOwnerEmail?.trim().toLowerCase() || ENV.ownerEmail; return Boolean(ENV.ownerOpenId && user.openId === ENV.ownerOpenId) || Boolean(approvedEmail && user.email?.trim().toLowerCase() === approvedEmail); };

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== 'admin' || !(await isConfiguredOwner(ctx.user))) {
      await recordSecurityEvent({ eventType: "unauthorized_admin_access", email: ctx.user?.email || null, openId: ctx.user?.openId || null, ipAddress: String(ctx.req.headers["x-forwarded-for"] || ctx.req.socket?.remoteAddress || "unknown"), userAgent: ctx.req.headers["user-agent"] || null, details: "Admin procedure rejected because the account is not the configured owner." });
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);
