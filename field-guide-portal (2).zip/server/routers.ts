import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { guideSeed } from "../shared/guideData";
import { guideChangeLog, guideFiles, guideSections, notifications, portalContent, portalContentHistory, portalSettings, questions } from "../drizzle/schema";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb, getPortalSettings, listAllGuideChanges, listGuideChanges, listGuideFiles, listGuideSections, listNotifications, listPortalContent, listPortalContentHistory, listQuestions, unreadNotificationCount, getPublicTickerSettings, getTickerSettings, upsertTickerSettings } from "./db";
import { storagePut } from "./storage";
import { invokeLLM } from "./_core/llm";
import { ENV } from "./_core/env";
import { notifyOwner } from "./_core/notification";
import { createHash, randomInt } from "node:crypto";
import { createOwnerEmailChallenge, getOwnerEmailChallenge, listSecurityEvents, recordSecurityEvent, updateOwnerEmailChallenge } from "./db";
const isConfiguredOwner = async (user: { openId: string; email: string | null }) => { const settings = await getPortalSettings(); const approvedEmail = settings?.approvedOwnerEmail?.trim().toLowerCase() || ENV.ownerEmail; return Boolean(ENV.ownerOpenId && user.openId === ENV.ownerOpenId) || Boolean(approvedEmail && user.email?.trim().toLowerCase() === approvedEmail); };
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== "admin" || !(await isConfiguredOwner(ctx.user))) { await recordSecurityEvent({ eventType: "unauthorized_admin_access", email: ctx.user.email || null, openId: ctx.user.openId, ipAddress: String(ctx.req.headers["x-forwarded-for"] || ctx.req.socket?.remoteAddress || "unknown"), userAgent: ctx.req.headers["user-agent"] || null, details: "Router admin procedure rejected." }); throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية متاحة لحساب مالك البوابة المعتمد فقط" }); }
  return next();
});
async function sendOtpEmail(to: string, code: string) {
  if (!ENV.resendApiKey) return false;
  const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${ENV.resendApiKey}` }, body: JSON.stringify({ from: ENV.mailFrom, to: [to], subject: "Meyar owner email verification code", html: `<p>Your Meyar verification code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:8px">${code}</p><p>This code expires in 10 minutes.</p>` }) });
  return response.ok;
}


const sectionInput = z.object({
  id: z.number().optional(), number: z.number().int().min(1), slug: z.string().min(1).max(120),
  title: z.string().min(1).max(255), summary: z.string().min(1), body: z.string().min(1),
  titleEn: z.string().min(1).max(255), summaryEn: z.string().min(1), bodyEn: z.string().min(1), accent: z.string().max(32).default("teal"),
});
const categorySchema = z.enum(["template", "policy", "report", "checklist", "other"]);

async function createNotification(kind: "question" | "comment" | "file", title: string, body: string, entityId?: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values({ kind, title, body, entityId, isRead: 0 });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  settings: router({
    get: publicProcedure.query(async () => {
      const row = await getPortalSettings();
      return row || { id: 0, siteNameAr: "مِعيار", siteNameEn: "Meyar", logoUrl: "/assets/logo-white.png", primaryColor: "#c81010", accentColor: "#242424", backgroundColor: "#f7f9fb", approvedOwnerEmail: ENV.ownerEmail, updatedAt: new Date(0) };
    }),
    update: adminProcedure.input(z.object({ siteNameAr: z.string().min(1).max(180), siteNameEn: z.string().min(1).max(180), primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/), accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/), backgroundColor: z.string().regex(/^#[0-9a-fA-F]{6}$/), logoData: z.string().nullable().optional(), logoMimeType: z.string().max(80).optional() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      let logoUrl: string | null | undefined = undefined;
      if (input.logoData) { const uploaded = await storagePut(`portal-assets/logo-${Date.now()}`, Buffer.from(input.logoData, "base64"), input.logoMimeType || "image/png"); logoUrl = uploaded.url; }
      if (input.logoData === null) logoUrl = null;
      const existing = await getPortalSettings();
      const values = { siteNameAr: input.siteNameAr, siteNameEn: input.siteNameEn, primaryColor: input.primaryColor, accentColor: input.accentColor, backgroundColor: input.backgroundColor, ...(logoUrl !== undefined ? { logoUrl } : {}) };
      if (existing) await db.update(portalSettings).set(values).where(eq(portalSettings.id, existing.id));
      else await db.insert(portalSettings).values({ ...values, logoUrl: logoUrl ?? null });
      return { success: true };
    }),
    securityEvents: adminProcedure.query(() => listSecurityEvents()),
    requestOwnerEmailChange: adminProcedure.input(z.object({ email: z.string().email().max(320) })).mutation(async ({ ctx, input }) => {
      const email = input.email.trim().toLowerCase();
      if (email === (ctx.user.email || "").trim().toLowerCase()) throw new TRPCError({ code: "BAD_REQUEST", message: "البريد الجديد يجب أن يختلف عن البريد الحالي" });
      const code = String(randomInt(100000, 1000000));
      const challengeId = await createOwnerEmailChallenge({ email, codeHash: createHash("sha256").update(code).digest("hex"), expiresAt: new Date(Date.now() + 10 * 60 * 1000), attempts: 0 });
      const emailed = await sendOtpEmail(email, code).catch(() => false); if (!emailed) await notifyOwner({ title: "Meyar owner email verification", content: `OTP for changing the approved owner email to ${email}: ${code}. It expires in 10 minutes.` });
      await recordSecurityEvent({ eventType: "owner_email_otp_requested", email, openId: ctx.user.openId, ipAddress: String(ctx.req.headers["x-forwarded-for"] || ctx.req.socket?.remoteAddress || "unknown"), userAgent: ctx.req.headers["user-agent"] || null, details: `Challenge ${challengeId} created.` });
      return { challengeId, expiresInSeconds: 600, maskedEmail: email.replace(/^(.{2}).*(@.*)$/, "$1••••$2") };
    }),
    confirmOwnerEmailChange: adminProcedure.input(z.object({ challengeId: z.number().int().positive(), code: z.string().regex(/^\d{6}$/) })).mutation(async ({ ctx, input }) => {
      const challenge = await getOwnerEmailChallenge(input.challengeId);
      if (!challenge || challenge.usedAt || challenge.expiresAt.getTime() < Date.now() || challenge.attempts >= 5) throw new TRPCError({ code: "BAD_REQUEST", message: "رمز التحقق غير صالح أو منتهي الصلاحية" });
      const valid = createHash("sha256").update(input.code).digest("hex") === challenge.codeHash;
      if (!valid) { await updateOwnerEmailChallenge(input.challengeId, { attempts: challenge.attempts + 1 }); await recordSecurityEvent({ eventType: "owner_email_otp_failed", email: challenge.email, openId: ctx.user.openId, details: `Challenge ${input.challengeId} failed.` }); throw new TRPCError({ code: "BAD_REQUEST", message: "رمز التحقق غير صحيح" }); }
      await updateOwnerEmailChallenge(input.challengeId, { usedAt: new Date() });
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const settings = await getPortalSettings();
      if (settings) await db.update(portalSettings).set({ approvedOwnerEmail: challenge.email }).where(eq(portalSettings.id, settings.id));
      else await db.insert(portalSettings).values({ siteNameAr: "مِعيار", siteNameEn: "Meyar", primaryColor: "#c81010", accentColor: "#242424", backgroundColor: "#f7f9fb", approvedOwnerEmail: challenge.email });
      ENV.ownerEmail = challenge.email;
      await recordSecurityEvent({ eventType: "owner_email_change_confirmed", email: challenge.email, openId: ctx.user.openId, details: "OTP confirmed; deployment configuration must be updated to make the new email authoritative." });
      return { success: true, email: challenge.email, requiresDeploymentConfig: false };
    }),
  }),
  content: router({
    list: publicProcedure.query(() => listPortalContent()),
    glossary: publicProcedure.query(async () => (await listPortalContent()).filter((item) => item.contentKey.startsWith("glossary.")).flatMap((item) => { try { return [{ id: item.contentKey.slice(9), ...(JSON.parse(item.valueAr) as Record<string, string>) }]; } catch { return []; } })),
    saveGlossary: adminProcedure.input(z.object({ id: z.string().min(1).max(80), termAr: z.string().min(1).max(180), termEn: z.string().min(1).max(180), definitionAr: z.string().min(1).max(2000), definitionEn: z.string().min(1).max(2000), objectiveAr: z.string().min(1).max(1000), objectiveEn: z.string().min(1).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const key = `glossary.${input.id.replace(/[^a-zA-Z0-9_-]/g, "-")}`; const value = JSON.stringify(input);
      await db.insert(portalContent).values({ contentKey: key, valueAr: value, valueEn: value, format: "text", updatedBy: ctx.user.id }).onDuplicateKeyUpdate({ set: { valueAr: value, valueEn: value, updatedBy: ctx.user.id } });
      return { success: true, id: input.id };
    }),
    deleteGlossary: adminProcedure.input(z.object({ id: z.string().min(1).max(80) })).mutation(async ({ input }) => { const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" }); await db.delete(portalContent).where(eq(portalContent.contentKey, `glossary.${input.id}`)); return { success: true }; }),
    suggest: adminProcedure.input(z.object({ text: z.string().min(3).max(20000), language: z.enum(["ar", "en"]), action: z.enum(["improve", "rewrite", "shorten"]).default("improve"), tone: z.enum(["formal", "creative", "concise"]).default("formal") })).mutation(async ({ input }) => {
      const action = input.action === "rewrite" ? "أعد صياغة النص" : input.action === "shorten" ? "اختصر النص مع الحفاظ على المعنى" : "حسّن اللغة والوضوح";
      const language = input.language === "ar" ? "العربية" : "English";
      const tone = input.tone === "creative" ? "استخدم نبرة إبداعية جذابة مع الحفاظ على المهنية" : input.tone === "concise" ? "استخدم نبرة مختصرة ومباشرة" : "استخدم نبرة رسمية مهنية";
      try {
        const response = await invokeLLM({ model: "gpt-5-mini", maxTokens: 1800, messages: [
          { role: "system", content: `You are a professional bilingual operational-guide editor. ${action} in ${language}. ${tone}. Preserve facts, numbers, acronyms, proper nouns, technical English terms, and the original intent. Return only the revised text, with no preface or quotation marks.` },
          { role: "user", content: input.text },
        ] });
        const content = response.choices[0]?.message?.content;
        const suggestion = typeof content === "string" ? content.trim() : "";
        if (!suggestion) throw new Error("Empty AI suggestion");
        return { suggestion };
      } catch (error) {
        console.error("[AI editor] suggestion failed", error);
        throw new TRPCError({ code: "BAD_GATEWAY", message: "تعذر إنشاء الاقتراح الذكي مؤقتًا" });
      }
    }),
    history: adminProcedure.query(() => listPortalContentHistory()),
    saveMany: adminProcedure.input(z.object({ changeType: z.enum(["save", "default"]).default("save"), items: z.array(z.object({ contentKey: z.string().min(1).max(180), valueAr: z.string().max(20000), valueEn: z.string().max(20000), format: z.enum(["text", "rich"]).default("text") })).min(1).max(500) })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const changedByName = ctx.user.name || ctx.user.email || "Owner";
      for (const item of input.items) {
        await db.insert(portalContent).values({ ...item, updatedBy: ctx.user.id }).onDuplicateKeyUpdate({ set: { valueAr: item.valueAr, valueEn: item.valueEn, format: item.format, updatedBy: ctx.user.id } });
        await db.insert(portalContentHistory).values({ ...item, changedBy: ctx.user.id, changedByName, changeType: input.changeType });
      }
      return { success: true, count: input.items.length };
    }),
    restore: adminProcedure.input(z.object({ historyId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const snapshot = (await db.select().from(portalContentHistory).where(eq(portalContentHistory.id, input.historyId)).limit(1))[0];
      if (!snapshot) throw new TRPCError({ code: "NOT_FOUND", message: "نسخة النص غير موجودة" });
      await db.insert(portalContent).values({ contentKey: snapshot.contentKey, valueAr: snapshot.valueAr, valueEn: snapshot.valueEn, format: snapshot.format, updatedBy: ctx.user.id }).onDuplicateKeyUpdate({ set: { valueAr: snapshot.valueAr, valueEn: snapshot.valueEn, format: snapshot.format, updatedBy: ctx.user.id } });
      await db.insert(portalContentHistory).values({ contentKey: snapshot.contentKey, valueAr: snapshot.valueAr, valueEn: snapshot.valueEn, format: snapshot.format, changedBy: ctx.user.id, changedByName: ctx.user.name || ctx.user.email || "Owner", changeType: "restore" });
      return { success: true, contentKey: snapshot.contentKey };
    }),
  }),
  guide: router({
    list: publicProcedure.query(async () => {
      const rows = await listGuideSections();
      if (rows.length) return rows;
      return guideSeed.map((section, index) => ({ id: index + 1, number: section.number, slug: section.slug, title: section.title, summary: section.summary, body: section.body, titleEn: section.titleEn, summaryEn: section.summaryEn, bodyEn: section.bodyEn, accent: section.accent, createdAt: new Date(0), updatedAt: new Date(0) }));
    }),
    changes: publicProcedure.input(z.object({ sectionId: z.number().int().positive() })).query(({ input }) => listGuideChanges(input.sectionId)),
    allChanges: adminProcedure.query(() => listAllGuideChanges()),
    seed: adminProcedure.mutation(async ({ ctx }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const existing = await db.select({ id: guideSections.id }).from(guideSections).limit(1);
      if (existing.length) {
        for (const section of guideSeed) {
          await db.update(guideSections).set({ number: section.number, title: section.title, summary: section.summary, body: section.body, titleEn: section.titleEn, summaryEn: section.summaryEn, bodyEn: section.bodyEn, accent: section.accent }).where(eq(guideSections.slug, section.slug));
        }
        const history = await db.select({ id: guideChangeLog.id }).from(guideChangeLog).limit(1);
        if (!history.length) {
          const current = await db.select().from(guideSections);
          await db.insert(guideChangeLog).values(current.map((section) => ({ sectionId: section.id, sectionTitle: section.title, changedBy: ctx.user.id, changedByName: ctx.user.name || ctx.user.email || "Owner", changeSummary: "Initial content snapshot", number: section.number, slug: section.slug, title: section.title, summary: section.summary, body: section.body, titleEn: section.titleEn, summaryEn: section.summaryEn || "", bodyEn: section.bodyEn || "", accent: section.accent })));
        }
        return { inserted: 0, updated: guideSeed.length };
      }
      await db.insert(guideSections).values(guideSeed.map(section => ({ number: section.number, slug: section.slug, title: section.title, summary: section.summary, body: section.body, titleEn: section.titleEn, summaryEn: section.summaryEn, bodyEn: section.bodyEn, accent: section.accent })));
      return { inserted: guideSeed.length, updated: 0 };
    }),
    save: adminProcedure.input(sectionInput).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const values = { number: input.number, slug: input.slug, title: input.title, summary: input.summary, body: input.body, titleEn: input.titleEn, summaryEn: input.summaryEn, bodyEn: input.bodyEn, accent: input.accent };
      if (input.id) { await db.update(guideSections).set(values).where(eq(guideSections.id, input.id)); await db.insert(guideChangeLog).values({ sectionId: input.id, sectionTitle: input.title, changedBy: ctx.user.id, changedByName: ctx.user.name || ctx.user.email || "Owner", changeSummary: "Updated Arabic and English content", ...values, summaryEn: values.summaryEn || "", bodyEn: values.bodyEn || "" }); return { id: input.id }; }
      const created = await db.insert(guideSections).values(values); return { id: Number(created[0].insertId) };
    }),
    restore: adminProcedure.input(z.object({ changeId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const snapshot = (await db.select().from(guideChangeLog).where(eq(guideChangeLog.id, input.changeId)).limit(1))[0];
      if (!snapshot) throw new TRPCError({ code: "NOT_FOUND", message: "نسخة التعديل غير موجودة" });
      const values = { number: snapshot.number, slug: snapshot.slug, title: snapshot.title, summary: snapshot.summary, body: snapshot.body, titleEn: snapshot.titleEn, summaryEn: snapshot.summaryEn, bodyEn: snapshot.bodyEn, accent: snapshot.accent };
      await db.update(guideSections).set(values).where(eq(guideSections.id, snapshot.sectionId));
      await db.insert(guideChangeLog).values({ sectionId: snapshot.sectionId, sectionTitle: snapshot.title, changedBy: ctx.user.id, changedByName: ctx.user.name || ctx.user.email || "Owner", changeSummary: `Restored version from ${snapshot.createdAt.toISOString()}`, ...values, summaryEn: values.summaryEn || "", bodyEn: values.bodyEn || "" });
      return { success: true, sectionId: snapshot.sectionId };
    }),
  }),
  questions: router({
    list: publicProcedure.query(listQuestions),
    ask: publicProcedure.input(z.object({ kind: z.enum(["question", "comment"]).default("question"), name: z.string().min(2).max(160), email: z.string().email(), question: z.string().min(8).max(5000), sectionSlug: z.string().max(120).optional() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "تعذر حفظ الاستفسار مؤقتًا" });
      const editToken = `${randomInt(100000, 999999)}-${Date.now()}-${randomInt(1000, 9999)}`;
      const created = await db.insert(questions).values({ ...input, email: input.email || null, editTokenHash: createHash("sha256").update(editToken).digest("hex") });
      const id = Number(created[0].insertId);
      await createNotification(input.kind, input.kind === "comment" ? "تعليق جديد" : "استفسار جديد", `${input.name}: ${input.question.slice(0, 120)}`, id);
      return { id, editToken };
    }),
    update: publicProcedure.input(z.object({ id: z.number().int().positive(), editToken: z.string().min(8).max(128), kind: z.enum(["question", "comment"]), name: z.string().min(2).max(160), email: z.string().email(), question: z.string().min(8).max(5000) })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const tokenHash = createHash("sha256").update(input.editToken).digest("hex");
      const existing = (await db.select({ editTokenHash: questions.editTokenHash }).from(questions).where(eq(questions.id, input.id)).limit(1))[0];
      if (!existing?.editTokenHash || existing.editTokenHash !== tokenHash) throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية تعديل هذا الاستفسار" });
      await db.update(questions).set({ kind: input.kind, name: input.name, email: input.email || null, question: input.question }).where(eq(questions.id, input.id));
      return { success: true } as const;
    }),
    claim: publicProcedure.input(z.object({ id: z.number().int().positive(), name: z.string().min(2).max(160), email: z.string().email() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const existing = (await db.select({ name: questions.name, email: questions.email }).from(questions).where(eq(questions.id, input.id)).limit(1))[0];
      if (!existing || existing.name.trim().toLowerCase() !== input.name.trim().toLowerCase() || !existing.email || existing.email.trim().toLowerCase() !== input.email.trim().toLowerCase()) throw new TRPCError({ code: "FORBIDDEN", message: "بيانات صاحب الاستفسار غير متطابقة" });
      const editToken = `${randomInt(100000, 999999)}-${Date.now()}-${randomInt(1000, 9999)}`;
      await db.update(questions).set({ editTokenHash: createHash("sha256").update(editToken).digest("hex") }).where(eq(questions.id, input.id));
      return { editToken } as const;
    }),
    remove: publicProcedure.input(z.object({ id: z.number().int().positive(), editToken: z.string().min(8).max(128) })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const tokenHash = createHash("sha256").update(input.editToken).digest("hex");
      const existing = (await db.select({ editTokenHash: questions.editTokenHash }).from(questions).where(eq(questions.id, input.id)).limit(1))[0];
      if (!existing?.editTokenHash || existing.editTokenHash !== tokenHash) throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية حذف هذا الاستفسار" });
      await db.delete(questions).where(eq(questions.id, input.id));
      return { success: true } as const;
    }),
    reply: adminProcedure.input(z.object({ id: z.number(), answer: z.string().min(2).max(10000) })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      await db.update(questions).set({ answer: input.answer, status: "answered", answeredBy: ctx.user.id, answeredAt: new Date() }).where(eq(questions.id, input.id)); return { success: true };
    }),
  }),
  files: router({
    list: publicProcedure.input(z.object({ sectionId: z.number().optional(), category: categorySchema.optional() }).optional()).query(async ({ input }) => {
      const files = await listGuideFiles();
      return files.filter(file => (!input?.sectionId || file.sectionId === input.sectionId) && (!input?.category || file.category === input.category));
    }),
    create: adminProcedure.input(z.object({ title: z.string().min(1).max(255), fileName: z.string().min(1).max(255), mimeType: z.string().max(160), size: z.number().int().positive().max(12_000_000), data: z.string().min(1), sectionId: z.number().optional(), category: categorySchema.default("other") })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-"); const key = `guide-files/${Date.now()}-${safeName}`;
      const uploaded = await storagePut(key, Buffer.from(input.data, "base64"), input.mimeType || "application/octet-stream");
      const created = await db.insert(guideFiles).values({ title: input.title, fileName: input.fileName, mimeType: input.mimeType, size: input.size, fileKey: uploaded.key, url: uploaded.url, category: input.category, sectionId: input.sectionId, uploadedBy: ctx.user.id });
      const id = Number(created[0].insertId);
      await createNotification("file", "ملف جديد", `${input.title} · ${input.category}`, id);
      return { id, url: uploaded.url };
    }),
    remove: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      await db.delete(guideFiles).where(eq(guideFiles.id, input.id)); return { success: true };
    }),
  }),
  ticker: router({
    get: publicProcedure.input(z.object({ language: z.enum(["ar", "en"]) })).query(({ input }) => getPublicTickerSettings(input.language)),
    save: adminProcedure.input(z.object({ language: z.enum(["ar", "en"]), speed: z.number().int().min(300).max(2000), direction: z.enum(["forward", "reverse"]), paused: z.boolean(), filter: z.string().max(32), textFilter: z.string().max(255) })).mutation(({ ctx, input }) => upsertTickerSettings(ctx.user.id, input.language, { ...input, paused: input.paused ? 1 : 0 })),
  }),
  notifications: router({
    list: adminProcedure.query(listNotifications),
    unreadCount: adminProcedure.query(unreadNotificationCount),
    markRead: adminProcedure.input(z.object({ id: z.number().optional() }).optional()).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة" });
      if (input?.id) await db.update(notifications).set({ isRead: 1 }).where(eq(notifications.id, input.id));
      else await db.update(notifications).set({ isRead: 1 }).where(eq(notifications.isRead, 0));
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
