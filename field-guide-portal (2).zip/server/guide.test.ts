import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { ENV } from "./_core/env";

function createPublicContext(): TrpcContext {
  return { user: null, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

function createAdminContext(): TrpcContext {
  return {
    user: { id: 1, openId: ENV.ownerOpenId || "owner", name: "Portal Owner", email: "owner@example.com", loginMethod: "manus", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("guide.list", () => {
  it("returns the full seeded guide in Arabic and English when the database has no rows", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const sections = await caller.guide.list();

    expect(sections).toHaveLength(40);
    expect(sections[0]).toMatchObject({ number: 1, slug: "section-1" });
    expect(sections.at(-1)).toMatchObject({ number: 40, slug: "section-40" });
    expect(sections[0]?.body).toContain("المستند وحده لا يثبت العملية");
    expect(sections[0]?.titleEn).toBeTruthy();
    expect(sections[0]?.bodyEn).toBeTruthy();
    const operatingReference = sections.find((section) => section.number === 32);
    expect(operatingReference?.body).toContain("الحزمة التشغيلية");
    expect(operatingReference?.body).not.toContain("يجب ألا يكون التدريب");
  });
});

describe("public questions and files", () => {
  it("returns public collections without requiring authentication", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const questions = await caller.questions.list();
    const files = await caller.files.list();

    expect(Array.isArray(questions)).toBe(true);
    expect(Array.isArray(files)).toBe(true);
    if (questions.length) expect(questions[0]).toMatchObject({ question: expect.any(String), kind: expect.stringMatching(/question|comment/) });
    if (files.length) expect(files[0]).toHaveProperty("url");
  });
});

describe("portal content editor", () => {
  it("allows public content reads but rejects public writes", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    const content = await publicCaller.content.list();
    expect(Array.isArray(content)).toBe(true);
    await expect(publicCaller.content.saveMany({ items: [{ contentKey: "hero", valueAr: "x", valueEn: "x", format: "text" }] })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(publicCaller.content.suggest({ text: "Sample text for editing", language: "en", action: "improve" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("protects history and restore operations for the owner", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    const adminCaller = appRouter.createCaller(createAdminContext());
    await expect(publicCaller.content.history()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    const history = await adminCaller.content.history();
    expect(Array.isArray(history)).toBe(true);
    await expect(adminCaller.content.restore({ historyId: 999999999 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("guide.changes", () => {
  it("returns a public change-history collection for a section", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const changes = await caller.guide.changes({ sectionId: 1 });
    expect(Array.isArray(changes)).toBe(true);
    if (changes.length) expect(changes[0]).toMatchObject({ sectionId: 1, changedByName: expect.any(String) });
  });
});

describe("guide owner history", () => {
  it("rejects an admin-role account that is not the configured owner", async () => {
    const context = createAdminContext();
    context.user = { ...context.user!, openId: "different-google-account" };
    await expect(appRouter.createCaller(context).guide.allChanges()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("returns the full change history only to an admin", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const changes = await caller.guide.allChanges();
    expect(Array.isArray(changes)).toBe(true);
    if (changes.length) expect(changes[0]).toMatchObject({ sectionId: expect.any(Number), body: expect.any(String), changedByName: expect.any(String) });
  });

  it("rejects restoring a missing version", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(caller.guide.restore({ changeId: 999999999 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});
