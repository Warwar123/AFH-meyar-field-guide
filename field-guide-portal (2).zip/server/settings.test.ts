import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: undefined,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("settings.get", () => {
  it("returns safe branded defaults for public visitors when no saved row exists", async () => {
    const result = await appRouter.createCaller(createContext()).settings.get();
    expect(result.siteNameAr).toBeTruthy();
    expect(result.siteNameEn).toBeTruthy();
    expect(result.primaryColor).toMatch(/^#[0-9a-f]{6}$/i);
    expect(result.logoUrl).toBeTruthy();
  });
});

describe("settings.update", () => {
  it("rejects unauthenticated settings changes", async () => {
    await expect(appRouter.createCaller(createContext()).settings.update({
      siteNameAr: "اسم جديد",
      siteNameEn: "New name",
      primaryColor: "#c81010",
      accentColor: "#242424",
      backgroundColor: "#f7f9fb",
    })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
