import { asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { guideChangeLog, guideFiles, guideSections, InsertUser, notifications, ownerEmailChallenges, portalContent, tickerSettings, portalContentHistory, portalSettings, questions, securityEvents, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() { if (!_db && process.env.DATABASE_URL) { try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; } } return _db; }

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb(); if (!db) return;
  const values: InsertUser = { openId: user.openId }; const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) { if (user[field] !== undefined) { const value = user[field] ?? null; values[field] = value; updateSet[field] = value; } }
  values.lastSignedIn = user.lastSignedIn ?? new Date(); updateSet.lastSignedIn = values.lastSignedIn;
  const settings = await getPortalSettings();
  const approvedEmail = settings?.approvedOwnerEmail?.trim().toLowerCase() || ENV.ownerEmail;
  const ownerByIdentity = Boolean(ENV.ownerOpenId && user.openId === ENV.ownerOpenId) || Boolean(approvedEmail && user.email?.trim().toLowerCase() === approvedEmail);
  if (ownerByIdentity) { values.role = "admin"; updateSet.role = "admin"; } else { values.role = "user"; updateSet.role = "user"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}
export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return rows[0]; }
export async function listGuideSections() { const db = await getDb(); if (!db) return []; return db.select().from(guideSections).orderBy(asc(guideSections.number)); }
export async function listQuestions() { const db = await getDb(); if (!db) return []; return db.select().from(questions).orderBy(desc(questions.createdAt)); }
export async function listGuideFiles() { const db = await getDb(); if (!db) return []; return db.select().from(guideFiles).orderBy(desc(guideFiles.createdAt)); }
export async function listNotifications() { const db = await getDb(); if (!db) return []; return db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(60); }
export async function unreadNotificationCount() { const db = await getDb(); if (!db) return 0; const rows = await db.select({ id: notifications.id }).from(notifications).where(eq(notifications.isRead, 0)); return rows.length; }
export async function getPortalSettings() { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(portalSettings).limit(1); return rows[0]; }
export async function listPortalContent() { const db = await getDb(); if (!db) return []; return db.select().from(portalContent); }
export async function listPortalContentHistory() { const db = await getDb(); if (!db) return []; return db.select().from(portalContentHistory).orderBy(desc(portalContentHistory.createdAt)); }
export async function listGuideChanges(sectionId: number) { const db = await getDb(); if (!db) return []; return db.select().from(guideChangeLog).where(eq(guideChangeLog.sectionId, sectionId)).orderBy(desc(guideChangeLog.createdAt)).limit(30); }
export async function listAllGuideChanges() { const db = await getDb(); if (!db) return []; return db.select().from(guideChangeLog).orderBy(desc(guideChangeLog.createdAt)).limit(200); }
export async function recordSecurityEvent(event: typeof securityEvents.$inferInsert) { const db = await getDb(); if (!db) return; await db.insert(securityEvents).values(event); }
export async function listSecurityEvents() { const db = await getDb(); if (!db) return []; return db.select().from(securityEvents).orderBy(desc(securityEvents.createdAt)).limit(300); }
export async function createOwnerEmailChallenge(challenge: typeof ownerEmailChallenges.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database unavailable"); const result = await db.insert(ownerEmailChallenges).values(challenge); return Number(result[0].insertId); }
export async function getOwnerEmailChallenge(id: number) { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(ownerEmailChallenges).where(eq(ownerEmailChallenges.id, id)).limit(1); return rows[0]; }
export async function updateOwnerEmailChallenge(id: number, values: Partial<typeof ownerEmailChallenges.$inferInsert>) { const db = await getDb(); if (!db) return; await db.update(ownerEmailChallenges).set(values).where(eq(ownerEmailChallenges.id, id)); }

export async function getTickerSettings(userId: number, language: "ar" | "en") { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(tickerSettings).where(eq(tickerSettings.userId, userId)).limit(10); return rows.find((row) => row.language === language); }
export async function getPublicTickerSettings(language: "ar" | "en") { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(tickerSettings).where(eq(tickerSettings.language, language)).orderBy(desc(tickerSettings.updatedAt)).limit(1); return rows[0]; }
export async function upsertTickerSettings(userId: number, language: "ar" | "en", values: { speed: number; direction: "forward" | "reverse"; paused: number; filter: string; textFilter: string }) { const db = await getDb(); if (!db) throw new Error("Database unavailable"); const existing = await getTickerSettings(userId, language); if (existing) { await db.update(tickerSettings).set(values).where(eq(tickerSettings.id, existing.id)); } else { await db.insert(tickerSettings).values({ userId, language, ...values }); } return getTickerSettings(userId, language); }
