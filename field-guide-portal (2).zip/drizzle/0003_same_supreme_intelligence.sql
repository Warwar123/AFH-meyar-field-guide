ALTER TABLE `guide_sections` MODIFY COLUMN `summaryEn` text;--> statement-breakpoint
ALTER TABLE `guide_sections` MODIFY COLUMN `bodyEn` text;