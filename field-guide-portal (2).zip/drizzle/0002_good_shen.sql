ALTER TABLE `guide_files` ADD `sectionId` int;--> statement-breakpoint
ALTER TABLE `guide_sections` ADD `titleEn` varchar(255) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `guide_sections` ADD `summaryEn` text;--> statement-breakpoint
ALTER TABLE `guide_sections` ADD `bodyEn` text;
