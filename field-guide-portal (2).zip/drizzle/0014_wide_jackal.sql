CREATE TABLE `ticker_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`language` enum('ar','en') NOT NULL,
	`speed` int NOT NULL DEFAULT 600,
	`direction` enum('forward','reverse') NOT NULL DEFAULT 'forward',
	`paused` int NOT NULL DEFAULT 0,
	`filter` varchar(32) NOT NULL DEFAULT 'all',
	`textFilter` varchar(255) NOT NULL DEFAULT '',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ticker_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `ticker_settings_user_language_idx` UNIQUE(`userId`,`language`)
);
