CREATE TABLE `guide_change_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sectionId` int NOT NULL,
	`sectionTitle` varchar(255) NOT NULL,
	`changedBy` int,
	`changedByName` varchar(255) NOT NULL,
	`changeSummary` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guide_change_log_id` PRIMARY KEY(`id`)
);
