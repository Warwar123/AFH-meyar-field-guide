CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kind` enum('question','comment','file') NOT NULL DEFAULT 'question',
	`title` varchar(255) NOT NULL,
	`body` text NOT NULL,
	`entityId` int,
	`isRead` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `guide_files` ADD `category` enum('template','policy','report','checklist','other') DEFAULT 'other' NOT NULL;