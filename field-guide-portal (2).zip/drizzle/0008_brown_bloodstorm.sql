ALTER TABLE `guide_change_log` ADD `number` int NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `slug` varchar(120) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `title` varchar(255) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `summary` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `body` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `titleEn` varchar(255) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `summaryEn` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `bodyEn` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` ADD `accent` varchar(32) NOT NULL DEFAULT '';
