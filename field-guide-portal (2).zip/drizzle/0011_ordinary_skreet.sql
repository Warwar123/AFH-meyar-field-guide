CREATE TABLE `portal_content_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentKey` varchar(180) NOT NULL,
	`valueAr` text NOT NULL DEFAULT (''),
	`valueEn` text NOT NULL DEFAULT (''),
	`format` enum('text','rich') NOT NULL DEFAULT 'text',
	`changedBy` int,
	`changedByName` varchar(255) NOT NULL,
	`changeType` enum('save','restore','default') NOT NULL DEFAULT 'save',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `portal_content_history_id` PRIMARY KEY(`id`)
);
