CREATE TABLE `guide_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(160) NOT NULL,
	`size` int NOT NULL,
	`fileKey` text NOT NULL,
	`url` text NOT NULL,
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guide_files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guide_sections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` int NOT NULL,
	`slug` varchar(120) NOT NULL,
	`title` varchar(255) NOT NULL,
	`summary` text NOT NULL,
	`body` text NOT NULL,
	`accent` varchar(32) NOT NULL DEFAULT 'teal',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `guide_sections_id` PRIMARY KEY(`id`),
	CONSTRAINT `guide_sections_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`email` varchar(320),
	`question` text NOT NULL,
	`sectionSlug` varchar(120),
	`status` enum('open','answered') NOT NULL DEFAULT 'open',
	`answer` text,
	`answeredBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`answeredAt` timestamp,
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
