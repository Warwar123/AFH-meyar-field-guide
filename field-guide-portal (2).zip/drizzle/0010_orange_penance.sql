CREATE TABLE `portal_content` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentKey` varchar(180) NOT NULL,
	`valueAr` text NOT NULL DEFAULT (''),
	`valueEn` text NOT NULL DEFAULT (''),
	`format` enum('text','rich') NOT NULL DEFAULT 'text',
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `portal_content_id` PRIMARY KEY(`id`),
	CONSTRAINT `portal_content_contentKey_unique` UNIQUE(`contentKey`)
);
