ALTER TABLE `guide_change_log` MODIFY COLUMN `number` int NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `slug` varchar(120) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `title` varchar(255) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `summary` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `body` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `titleEn` varchar(255) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `summaryEn` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `bodyEn` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `guide_change_log` MODIFY COLUMN `accent` varchar(32) NOT NULL DEFAULT '';