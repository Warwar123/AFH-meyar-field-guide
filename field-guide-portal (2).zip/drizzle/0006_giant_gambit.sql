CREATE TABLE `portal_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`siteNameAr` varchar(180) NOT NULL DEFAULT 'مِعيار',
	`siteNameEn` varchar(180) NOT NULL DEFAULT 'Meyar',
	`logoUrl` text,
	`primaryColor` varchar(7) NOT NULL DEFAULT '#c81010',
	`accentColor` varchar(7) NOT NULL DEFAULT '#242424',
	`backgroundColor` varchar(7) NOT NULL DEFAULT '#f7f9fb',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `portal_settings_id` PRIMARY KEY(`id`)
);
