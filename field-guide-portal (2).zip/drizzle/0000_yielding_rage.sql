DROP TABLE `guide_change_log`;--> statement-breakpoint
DROP TABLE `guide_files`;--> statement-breakpoint
DROP TABLE `guide_sections`;--> statement-breakpoint
DROP TABLE `notifications`;--> statement-breakpoint
DROP TABLE `owner_email_challenges`;--> statement-breakpoint
DROP TABLE `portal_content`;--> statement-breakpoint
DROP TABLE `portal_content_history`;--> statement-breakpoint
DROP TABLE `portal_settings`;--> statement-breakpoint
DROP TABLE `questions`;--> statement-breakpoint
DROP TABLE `security_events`;--> statement-breakpoint
DROP TABLE `ticker_settings`;