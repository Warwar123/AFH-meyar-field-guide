import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, uniqueIndex } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(), openId: varchar("openId", { length: 64 }).notNull().unique(), name: text("name"), email: varchar("email", { length: 320 }), loginMethod: varchar("loginMethod", { length: 64 }), role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(), lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const guideSections = mysqlTable("guide_sections", {
  id: int("id").autoincrement().primaryKey(), number: int("number").notNull(), slug: varchar("slug", { length: 120 }).notNull().unique(), title: varchar("title", { length: 255 }).notNull(), summary: text("summary").notNull(), body: text("body").notNull(), titleEn: varchar("titleEn", { length: 255 }).default("").notNull(), summaryEn: text("summaryEn"), bodyEn: text("bodyEn"), accent: varchar("accent", { length: 32 }).default("teal").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(), kind: mysqlEnum("kind", ["question", "comment"]).default("question").notNull(), name: varchar("name", { length: 160 }).notNull(), email: varchar("email", { length: 320 }), question: text("question").notNull(), sectionSlug: varchar("sectionSlug", { length: 120 }), status: mysqlEnum("status", ["open", "answered"]).default("open").notNull(), answer: text("answer"), answeredBy: int("answeredBy"), createdAt: timestamp("createdAt").defaultNow().notNull(), answeredAt: timestamp("answeredAt"), editTokenHash: varchar("editTokenHash", { length: 128 }),
});

export const guideFiles = mysqlTable("guide_files", {
  id: int("id").autoincrement().primaryKey(), title: varchar("title", { length: 255 }).notNull(), fileName: varchar("fileName", { length: 255 }).notNull(), mimeType: varchar("mimeType", { length: 160 }).notNull(), size: int("size").notNull(), fileKey: text("fileKey").notNull(), url: text("url").notNull(), category: mysqlEnum("category", ["template", "policy", "report", "checklist", "other"]).default("other").notNull(), sectionId: int("sectionId"), uploadedBy: int("uploadedBy"), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(), kind: mysqlEnum("kind", ["question", "comment", "file"]).default("question").notNull(), title: varchar("title", { length: 255 }).notNull(), body: text("body").notNull(), entityId: int("entityId"), isRead: int("isRead").default(0).notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const tickerSettings = mysqlTable("ticker_settings", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), language: mysqlEnum("language", ["ar", "en"]).notNull(), speed: int("speed").default(600).notNull(), direction: mysqlEnum("direction", ["forward", "reverse"]).default("forward").notNull(), paused: int("paused").default(0).notNull(), filter: varchar("filter", { length: 32 }).default("all").notNull(), textFilter: varchar("textFilter", { length: 255 }).default("").notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ userLanguageIdx: uniqueIndex("ticker_settings_user_language_idx").on(table.userId, table.language) }));
export const portalSettings = mysqlTable("portal_settings", {
  id: int("id").autoincrement().primaryKey(), siteNameAr: varchar("siteNameAr", { length: 180 }).default("مِعيار").notNull(), siteNameEn: varchar("siteNameEn", { length: 180 }).default("Meyar").notNull(), logoUrl: text("logoUrl"), primaryColor: varchar("primaryColor", { length: 7 }).default("#c81010").notNull(), accentColor: varchar("accentColor", { length: 7 }).default("#242424").notNull(), backgroundColor: varchar("backgroundColor", { length: 7 }).default("#f7f9fb").notNull(), approvedOwnerEmail: varchar("approvedOwnerEmail", { length: 320 }), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const securityEvents = mysqlTable("security_events", {
  id: int("id").autoincrement().primaryKey(), eventType: varchar("eventType", { length: 64 }).notNull(), email: varchar("email", { length: 320 }), openId: varchar("openId", { length: 120 }), ipAddress: varchar("ipAddress", { length: 128 }), userAgent: text("userAgent"), details: text("details"), createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export const ownerEmailChallenges = mysqlTable("owner_email_challenges", {
  id: int("id").autoincrement().primaryKey(), email: varchar("email", { length: 320 }).notNull(), codeHash: varchar("codeHash", { length: 128 }).notNull(), expiresAt: timestamp("expiresAt").notNull(), attempts: int("attempts").default(0).notNull(), usedAt: timestamp("usedAt"), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const portalContent = mysqlTable("portal_content", {
  id: int("id").autoincrement().primaryKey(), contentKey: varchar("contentKey", { length: 180 }).notNull().unique(), valueAr: text("valueAr").default("").notNull(), valueEn: text("valueEn").default("").notNull(), format: mysqlEnum("format", ["text", "rich"]).default("text").notNull(), updatedBy: int("updatedBy"), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const portalContentHistory = mysqlTable("portal_content_history", {
  id: int("id").autoincrement().primaryKey(), contentKey: varchar("contentKey", { length: 180 }).notNull(), valueAr: text("valueAr").default("").notNull(), valueEn: text("valueEn").default("").notNull(), format: mysqlEnum("format", ["text", "rich"]).default("text").notNull(), changedBy: int("changedBy"), changedByName: varchar("changedByName", { length: 255 }).notNull(), changeType: mysqlEnum("changeType", ["save", "restore", "default"]).default("save").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const guideChangeLog = mysqlTable("guide_change_log", {
  id: int("id").autoincrement().primaryKey(), sectionId: int("sectionId").notNull(), sectionTitle: varchar("sectionTitle", { length: 255 }).notNull(), changedBy: int("changedBy"), changedByName: varchar("changedByName", { length: 255 }).notNull(), changeSummary: varchar("changeSummary", { length: 500 }).notNull(), number: int("number").default(0).notNull(), slug: varchar("slug", { length: 120 }).default("").notNull(), title: varchar("title", { length: 255 }).default("").notNull(), summary: text("summary").default("").notNull(), body: text("body").default("").notNull(), titleEn: varchar("titleEn", { length: 255 }).default("").notNull(), summaryEn: text("summaryEn").default("").notNull(), bodyEn: text("bodyEn").default("").notNull(), accent: varchar("accent", { length: 32 }).default("").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type GuideSection = typeof guideSections.$inferSelect;
export type Question = typeof questions.$inferSelect;
export type GuideFile = typeof guideFiles.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type PortalSettings = typeof portalSettings.$inferSelect;
export type SecurityEvent = typeof securityEvents.$inferSelect;
export type PortalContent = typeof portalContent.$inferSelect;
export type PortalContentHistory = typeof portalContentHistory.$inferSelect;
export type GuideChangeLog = typeof guideChangeLog.$inferSelect;
