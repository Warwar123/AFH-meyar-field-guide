import { eq } from "drizzle-orm";
import { guideSections } from "../drizzle/schema";
import { guideSeed } from "../shared/guideData";
import { getDb } from "../server/db";

const db = await getDb();
if (!db) throw new Error("DATABASE_URL is unavailable");

for (const section of guideSeed) {
  const values = {
    number: section.number,
    slug: section.slug,
    title: section.title,
    summary: section.summary,
    body: section.body,
    titleEn: section.titleEn,
    summaryEn: section.summaryEn,
    bodyEn: section.bodyEn,
    accent: section.accent,
  };
  const existing = await db.select({ id: guideSections.id }).from(guideSections).where(eq(guideSections.slug, section.slug)).limit(1);
  if (existing.length) await db.update(guideSections).set(values).where(eq(guideSections.slug, section.slug));
  else await db.insert(guideSections).values(values);
}
console.log(`synced ${guideSeed.length} guide sections`);
