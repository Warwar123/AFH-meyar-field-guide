import { like, sql } from "drizzle-orm";
import { guideSections } from "../drizzle/schema";
import { getDb } from "../server/db";
const db = await getDb();
if (!db) throw new Error("DATABASE_URL is unavailable");
const rows = await db.select({ count: sql<number>`count(*)`, oldPhrases: sql<number>`sum(case when ${guideSections.body} like '%يجب تدريب الموظفين%' then 1 else 0 end)`, reframed: sql<number>`sum(case when ${guideSections.body} like '%إشارات الخطر والضوابط%' then 1 else 0 end)` }).from(guideSections);
console.log(JSON.stringify(rows[0]));
process.exit(0);
