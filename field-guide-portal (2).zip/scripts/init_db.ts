import mysql from "mysql2/promise";

async function main() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL!);
  
  const tables = [
    `CREATE TABLE IF NOT EXISTS \`users\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`openId\` varchar(64) NOT NULL UNIQUE,
      \`name\` text,
      \`email\` varchar(320),
      \`loginMethod\` varchar(64),
      \`role\` enum('user', 'admin') NOT NULL DEFAULT 'user',
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      \`lastSignedIn\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`guide_sections\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`number\` int NOT NULL,
      \`slug\` varchar(120) NOT NULL UNIQUE,
      \`title\` varchar(255) NOT NULL,
      \`summary\` text NOT NULL,
      \`body\` text NOT NULL,
      \`titleEn\` varchar(255) NOT NULL DEFAULT '',
      \`summaryEn\` text,
      \`bodyEn\` text,
      \`accent\` varchar(32) NOT NULL DEFAULT 'teal',
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`questions\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`kind\` enum('question', 'comment') NOT NULL DEFAULT 'question',
      \`name\` varchar(160) NOT NULL,
      \`email\` varchar(320),
      \`question\` text NOT NULL,
      \`sectionSlug\` varchar(120),
      \`status\` enum('open', 'answered') NOT NULL DEFAULT 'open',
      \`answer\` text,
      \`answeredBy\` int,
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`answeredAt\` timestamp NULL
    );`,
    `CREATE TABLE IF NOT EXISTS \`guide_files\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`title\` varchar(255) NOT NULL,
      \`fileName\` varchar(255) NOT NULL,
      \`mimeType\` varchar(160) NOT NULL,
      \`size\` int NOT NULL,
      \`fileKey\` text NOT NULL,
      \`url\` text NOT NULL,
      \`category\` enum('template', 'policy', 'report', 'checklist', 'other') NOT NULL DEFAULT 'other',
      \`sectionId\` int,
      \`uploadedBy\` int,
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`notifications\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`kind\` enum('question', 'comment', 'file') NOT NULL DEFAULT 'question',
      \`title\` varchar(255) NOT NULL,
      \`body\` text NOT NULL,
      \`entityId\` int,
      \`isRead\` int NOT NULL DEFAULT 0,
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`ticker_settings\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`userId\` int NOT NULL,
      \`language\` enum('ar', 'en') NOT NULL,
      \`speed\` int NOT NULL DEFAULT 600,
      \`direction\` enum('forward', 'reverse') NOT NULL DEFAULT 'forward',
      \`paused\` int NOT NULL DEFAULT 0,
      \`filter\` varchar(32) NOT NULL DEFAULT 'all',
      \`textFilter\` varchar(255) NOT NULL DEFAULT '',
      \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY \`ticker_settings_user_language_idx\` (\`userId\`, \`language\`)
    );`,
    `CREATE TABLE IF NOT EXISTS \`portal_settings\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`siteNameAr\` varchar(180) NOT NULL DEFAULT 'مِعيار',
      \`siteNameEn\` varchar(180) NOT NULL DEFAULT 'Meyar',
      \`logoUrl\` text,
      \`primaryColor\` varchar(7) NOT NULL DEFAULT '#c81010',
      \`accentColor\` varchar(7) NOT NULL DEFAULT '#242424',
      \`backgroundColor\` varchar(7) NOT NULL DEFAULT '#f7f9fb',
      \`approvedOwnerEmail\` varchar(320),
      \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`security_events\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`eventType\` varchar(64) NOT NULL,
      \`email\` varchar(320),
      \`openId\` varchar(120),
      \`ipAddress\` varchar(128),
      \`userAgent\` text,
      \`details\` text,
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`owner_email_challenges\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`email\` varchar(320) NOT NULL,
      \`codeHash\` varchar(128) NOT NULL,
      \`expiresAt\` timestamp NOT NULL,
      \`attempts\` int NOT NULL DEFAULT 0,
      \`usedAt\` timestamp NULL,
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`portal_content\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`contentKey\` varchar(180) NOT NULL UNIQUE,
      \`valueAr\` text NOT NULL,
      \`valueEn\` text NOT NULL,
      \`format\` enum('text', 'rich') NOT NULL DEFAULT 'text',
      \`updatedBy\` int,
      \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`portal_content_history\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`contentKey\` varchar(180) NOT NULL,
      \`valueAr\` text NOT NULL,
      \`valueEn\` text NOT NULL,
      \`format\` enum('text', 'rich') NOT NULL DEFAULT 'text',
      \`changedBy\` int,
      \`changedByName\` varchar(255) NOT NULL,
      \`changeType\` enum('save', 'restore', 'default') NOT NULL DEFAULT 'save',
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE TABLE IF NOT EXISTS \`guide_change_log\` (
      \`id\` int AUTO_INCREMENT PRIMARY KEY,
      \`sectionId\` int NOT NULL,
      \`sectionTitle\` varchar(255) NOT NULL,
      \`changedBy\` int,
      \`changedByName\` varchar(255) NOT NULL,
      \`changeSummary\` varchar(500) NOT NULL,
      \`number\` int NOT NULL DEFAULT 0,
      \`slug\` varchar(120) NOT NULL DEFAULT '',
      \`title\` varchar(255) NOT NULL DEFAULT '',
      \`summary\` text NOT NULL,
      \`body\` text NOT NULL,
      \`titleEn\` varchar(255) NOT NULL DEFAULT '',
      \`summaryEn\` text NOT NULL,
      \`bodyEn\` text NOT NULL,
      \`accent\` varchar(32) NOT NULL DEFAULT '',
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
    );`
  ];

  for (const sql of tables) {
    try {
      await connection.query(sql);
      console.log("Executed SQL statement successfully");
    } catch (err) {
      console.error("Error executing statement:", err);
    }
  }

  await connection.end();
}

main().catch(console.error);
