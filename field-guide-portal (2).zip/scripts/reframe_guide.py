from pathlib import Path
import json
import re

path = Path('/home/ubuntu/field-guide-portal/shared/guideData.ts')
text = path.read_text(encoding='utf-8')
header, payload = text.split('export const guideSeed: GuideSeedSection[] = ', 1)
data = json.loads(payload.rstrip().rstrip(';').strip())

def set_section(number, title, body, title_en, body_en):
    item = next(section for section in data if section['number'] == number)
    item['title'] = title
    item['body'] = body
    item['titleEn'] = title_en
    item['bodyEn'] = body_en
    item['summary'] = re.sub(r'\s+', ' ', body)[:190]
    item['summaryEn'] = re.sub(r'\s+', ' ', body_en)[:190]

set_section(29, 'التاسع والعشرون: إشارات الخطر والضوابط الوقائية', '''تُستخدم قائمة إشارات الخطر التالية كاختبار رقابي قبل اعتماد المعاملة أو إقفال الملف:
• Missing approvals.
• Same quotation format from multiple suppliers.
• Invoice without payment evidence.
• Payment without invoice.
• Payment before approval.
• Retroactive approvals.
• Duplicate invoice or duplicate payment.
• Round-number transactions.
• Unexplained adjustments.
• Old advances.
• Unsupported journal entries.
• Unreconciled bank items.
• Excessive petty cash.
• Staff charged to projects without allocation evidence.
• Procurement split to avoid thresholds.
• Screenshots replacing formal documentation.
• Personal bank accounts used without approved exception.
• Unclear supplier bank details.
• Conflict of interest.
• Expired contracts.
• Expenditure outside project period.
تُسجل كل إشارة مؤكدة في سجل الملاحظات مع تحديد السبب الجذري والإجراء التصحيحي والمسؤول والموعد النهائي.''', 'Twenty-Ninth: Red Flags and Preventive Controls', '''Use the following red-flag list as a control test before approving a transaction or closing a file:
• Missing approvals.
• Same quotation format from multiple suppliers.
• Invoice without payment evidence.
• Payment without invoice.
• Payment before approval.
• Retroactive approvals.
• Duplicate invoice or duplicate payment.
• Round-number transactions.
• Unexplained adjustments.
• Old advances.
• Unsupported journal entries.
• Unreconciled bank items.
• Excessive petty cash.
• Staff charged to projects without allocation evidence.
• Procurement split to avoid thresholds.
• Screenshots replacing formal documentation.
• Personal bank accounts used without approved exception.
• Unclear supplier bank details.
• Conflict of interest.
• Expired contracts.
• Expenditure outside project period.
Record each confirmed red flag in the issues log with its root cause, corrective action, owner, and due date.''')

set_section(32, 'الثاني والثلاثون: بنية المرجع التشغيلي', '''تُبنى الحزمة التشغيلية على مراجع مترابطة، وليس على شرح تدريبي منفصل:
1. Governance, Internal Control & Compliance.
2. Finance Procedures and Month-End Closing.
3. Procurement and Contract Management.
4. Logistics, Assets, Warehouse & Fleet.
5. HR, Payroll and Staff Files.
6. Programme Documentation and Beneficiary Evidence.
7. Project Management, Grants and Donor Compliance.
8. Budget Management and Financial Reporting.
9. Cash, Bank, Advances and Reconciliation.
10. Filing, Retention, Audit Readiness and Corrective Action.
يجب أن يرتبط كل مرجع بجدول العملية والمستند المطلوب وقائمة التحقق وسجل المتابعة ونقطة الرقابة.''', 'Thirty-Second: Operating Reference Structure', '''The operating package is built as a set of connected references, not as a standalone training narrative:
1. Governance, Internal Control & Compliance.
2. Finance Procedures and Month-End Closing.
3. Procurement and Contract Management.
4. Logistics, Assets, Warehouse & Fleet.
5. HR, Payroll and Staff Files.
6. Programme Documentation and Beneficiary Evidence.
7. Project Management, Grants and Donor Compliance.
8. Budget Management and Financial Reporting.
9. Cash, Bank, Advances and Reconciliation.
10. Filing, Retention, Audit Readiness and Corrective Action.
Each reference must link to the process matrix, required evidence, checklist, tracker, and control point.''')

set_section(33, 'الثالث والثلاثون: سيناريو التحقق التشغيلي', '''يُستخدم سيناريو شراء 20 جهاز حاسوب كاختبار موحد لاكتمال مسار المعاملة:
Need → PR → Budget Check → RFQ → Quotations → CBA → Approval → PO → Delivery → GRN → Invoice → Payment → Asset Register → Accounting → BvA
يُراجع الملف للتحقق من:
• اكتمال المستندات.
• صحة التسلسل والموافقات.
• توفر الميزانية والترميز.
• سلامة إجراءات الشراء والاستلام.
• وجود دليل الدفع والقيد المحاسبي.
• الالتزام بمتطلبات المانح.
• اكتمال الحفظ والتسمية.
تُوثق الفجوات في سجل الإجراءات التصحيحية بدل الاكتفاء بطلب المستند الناقص.''', 'Thirty-Third: Operating Verification Scenario', '''Use a 20-laptop procurement scenario as a standard test of transaction completeness:
Need → PR → Budget Check → RFQ → Quotations → CBA → Approval → PO → Delivery → GRN → Invoice → Payment → Asset Register → Accounting → BvA
Review the file for:
• Document completeness.
• Correct sequence and approvals.
• Budget availability and coding.
• Sound procurement and receipt evidence.
• Payment evidence and accounting entry.
• Donor compliance.
• Filing and naming completeness.
Record gaps in the corrective-action log instead of only requesting the missing document.''')

set_section(40, 'الأربعون: مكونات نظام الامتثال التشغيلي', '''يتكون النظام التشغيلي المعتمد من:
A. Field Office Compliance Reference.
B. Process and Document Matrix.
C. Approved AFH SOP and Policy Library.
D. Master Checklists لكل من Finance وProcurement وHR وLogistics وProgramme وDonor Compliance.
E. Forms and Templates Pack.
F. Trackers and Registers Pack.
G. Donor Compliance Matrix.
H. Monthly Compliance Dashboard.
I. Audit Readiness and Self-Assessment.
J. Corrective Action and Continuous Improvement Log.
المبدأ الحاكم:
One Process – One Complete File – One Clear Audit Trail
أي معاملة يجب أن تكون:
Budgeted → Authorized → Properly Procured/Implemented → Received → Invoiced → Paid → Accounted → Reconciled → Reported → Filed
ولا تعتبر العملية مكتملة حتى تكتمل هذه السلسلة وترتبط بالسياسة والمانح ونقطة الفحص المناسبة.''', 'Fortieth: Operating Compliance System Components', '''The approved operating system consists of:
A. Field Office Compliance Reference.
B. Process and Document Matrix.
C. Approved AFH SOP and Policy Library.
D. Master Checklists for Finance, Procurement, HR, Logistics, Programme and Donor Compliance.
E. Forms and Templates Pack.
F. Trackers and Registers Pack.
G. Donor Compliance Matrix.
H. Monthly Compliance Dashboard.
I. Audit Readiness and Self-Assessment.
J. Corrective Action and Continuous Improvement Log.
Governing principle:
One Process – One Complete File – One Clear Audit Trail
Every transaction must be:
Budgeted → Authorized → Properly Procured/Implemented → Received → Invoiced → Paid → Accounted → Reconciled → Reported → Filed
A transaction is complete only when this chain is complete and linked to the relevant policy, donor requirement, and control point.''')

out = header + 'export const guideSeed: GuideSeedSection[] = ' + json.dumps(data, ensure_ascii=False, indent=2) + ';\n'
path.write_text(out, encoding='utf-8')
print('reframed sections 29, 32, 33 and 40')
