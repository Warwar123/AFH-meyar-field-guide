from pathlib import Path
import concurrent.futures as cf
import json
import re
from openai import OpenAI

SOURCE = Path('/home/ubuntu/upload/pasted_content.txt').read_text(encoding='utf-8')
lines = SOURCE.splitlines()
pattern = re.compile(r'^الجزء\s+([^:]+):\s*(.*)$')
sections = []
current = None
for line in lines:
    match = pattern.match(line.strip())
    if match:
        if current:
            sections.append(current)
        current = {'number': len(sections) + 1, 'title': f'{match.group(1).strip()}: {match.group(2).strip()}', 'body': []}
    elif current and line.strip() and not set(line.strip()) <= {'_', '-'}:
        current['body'].append(line.rstrip())
if current:
    sections.append(current)
for section in sections:
    section['body'] = '\n'.join(section['body']).strip()
    compact = re.sub(r'\s+', ' ', section['body'])
    section['summary'] = (compact[:190] + '…') if len(compact) > 190 else compact
    section['slug'] = f"section-{section['number']}"
    section['accent'] = ['teal', 'gold', 'blue', 'violet'][section['number'] % 4]

client = OpenAI()
def translate(section):
    prompt = f'''Translate this Arabic NGO field-office training guide section into professional, precise international English.
Preserve every numbered item, bullet, arrow, acronym, policy term, and ordering. Do not summarize or omit anything.
Keep the body as plain text with the same line breaks. Translate Arabic prose, while retaining established English terms such as PR, RFQ, CBA, PO, GRN, Budget vs Actual, Donor Compliance, and Evidence Trail.
Return JSON only with title, summary, body.
TITLE: {section["title"]}
SUMMARY: {section["summary"]}
BODY:\n{section["body"]}'''
    response = client.chat.completions.create(
        model='gpt-5-mini',
        messages=[
            {'role': 'system', 'content': 'You are a meticulous bilingual technical translator. Output valid JSON only.'},
            {'role': 'user', 'content': prompt},
        ],
        response_format={'type': 'json_object'},
    )
    result = json.loads(response.choices[0].message.content)
    return section | {'titleEn': result['title'], 'summaryEn': result['summary'], 'bodyEn': result['body']}

with cf.ThreadPoolExecutor(max_workers=4) as executor:
    translated = list(executor.map(translate, sections))

out = Path('/home/ubuntu/field-guide-portal/shared/guideData.ts')
out.write_text(
    'export type GuideSeedSection = { number: number; slug: string; title: string; summary: string; body: string; accent: string; titleEn: string; summaryEn: string; bodyEn: string };\n\n'
    + 'export const guideSeed: GuideSeedSection[] = ' + json.dumps(translated, ensure_ascii=False, indent=2) + ';\n',
    encoding='utf-8'
)
print(f'translated {len(translated)} sections')
print(f'english characters: {sum(len(item["bodyEn"]) for item in translated):,}')
