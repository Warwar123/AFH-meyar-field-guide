import { guideChangeLog, guideSections } from "../drizzle/schema";
import { getDb } from "../server/db";

const db = await getDb();
if (!db) throw new Error("Database unavailable");
const existing = await db.select({ id: guideChangeLog.id }).from(guideChangeLog).limit(1);
if (existing.length) {
  console.log("history already initialized");
} else {
  const sections = await db.select().from(guideSections);
  if (sections.length) {
    await db.insert(guideChangeLog).values(sections.map((section) => ({
      sectionId: section.id,
      sectionTitle: section.title,
      changedBy: null,
      changedByName: "System baseline",
      changeSummary: "Initial content snapshot",
      number: section.number,
      slug: section.slug,
      title: section.title,
      summary: section.summary,
      body: section.body,
      titleEn: section.titleEn,
      summaryEn: section.summaryEn || "",
      bodyEn: section.bodyEn || "",
      accent: section.accent,
    })));
    console.log(`seeded ${sections.length} baseline snapshots`);
  }
}
process.exit(0);
