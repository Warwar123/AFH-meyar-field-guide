from pathlib import Path
import json

path = Path('/home/ubuntu/field-guide-portal/shared/guideData.ts')
lines = path.read_text(encoding='utf-8').splitlines()

section4 = '''<h3>Stage 1 — Determining the need</h3>
<p>The procurement file should begin with a clear need, an approved budget and a documented connection to the project or activity.</p>
<table><thead><tr><th>Required document</th><th>Purpose</th></tr></thead><tbody><tr><td>Programme/activity plan</td><td>Shows the operational need.</td></tr><tr><td>Approved budget</td><td>Confirms budget availability.</td></tr><tr><td>Procurement plan</td><td>Places the purchase in the planned cycle.</td></tr><tr><td>Purchase Requisition — PR</td><td>Starts and authorizes the request.</td></tr><tr><td>Technical specifications / ToR</td><td>Defines the required quality and scope.</td></tr><tr><td>Justification of need</td><td>Explains why the purchase is necessary.</td></tr></tbody></table>
<h3>What the PR must answer</h3>
<ul><li>What is being purchased?</li><li>Why is it needed?</li><li>For which project and activity?</li><li>What quantity, specification, duration and budget apply?</li><li>Who requested and who approved it?</li></ul>
<h3>Stage 2 — Obtaining quotations</h3>
<table><thead><tr><th>Evidence</th><th>Control expectation</th></tr></thead><tbody><tr><td>RFQ and supplier list</td><td>Evidence that the market was approached.</td></tr><tr><td>Supplier quotations</td><td>Comparable offers with supplier details.</td></tr><tr><td>Communication and collection evidence</td><td>Proof of when and how quotations were obtained.</td></tr><tr><td>Conflict of Interest declarations</td><td>Completed where required.</td></tr><tr><td>Vendor due diligence</td><td>Supplier eligibility and risk checks.</td></tr></tbody></table>
<blockquote><strong>Common error:</strong> Three quotations are not enough when dates, specifications or supplier information are inconsistent, when there is no RFQ evidence, or when the selection was made before quotations were received.</blockquote>
<h3>Stage 3 — Bid Analysis / CBA</h3>
<table><thead><tr><th>Comparison field</th><th>Required record</th></tr></thead><tbody><tr><td>Supplier and quotation</td><td>Names, offers and quoted prices.</td></tr><tr><td>Commercial terms</td><td>Unit price, total price, currency, delivery time and payment terms.</td></tr><tr><td>Technical compliance</td><td>Specifications, evaluation criteria and warranty where applicable.</td></tr><tr><td>Decision</td><td>Recommended supplier, reason for selection and approval signatures.</td></tr></tbody></table>
<blockquote><strong>Important rule:</strong> Lowest price does not automatically mean best supplier. The reason for selecting another supplier must be documented.</blockquote>
<h3>Stage 4 — Purchase Order / Contract</h3>
<p>The file should link the approved PO or contract with the quotation, CBA, approval, supplier registration, verified bank details and tax documentation where applicable.</p>
<p class="flow">PR → RFQ → Quotations → CBA → PO → Contract → Invoice → Payment</p>
<h3>Stage 5 — Receipt of goods or services</h3>
<table><thead><tr><th>Goods</th><th>Services</th></tr></thead><tbody><tr><td>Delivery Note, GRN, warehouse entry, quality/quantity verification, inspection and stock record.</td><td>Service completion confirmation, deliverable, activity report, timesheet where applicable, acceptance confirmation and programme/technical approval.</td></tr></tbody></table>
<h3>Stage 6 — Invoice review</h3>
<p>Check the supplier name, invoice number and date, description, quantity, unit price, total, currency, tax/VAT where applicable, contract/PO reference and project/UPRN where required.</p>
<h3>Stage 7 — Payment</h3>
<p>The final file should contain, as applicable: PR, approval, RFQ, quotations, CBA, PO/Contract, Delivery/GRN, Invoice, Payment Approval, Payment Voucher, Bank Evidence and Accounting Evidence. A reviewer should be able to trace the transaction without asking the employee.</p>'''

section27 = '''<h3>Review tools to be adopted</h3>
<table><thead><tr><th>Tool</th><th>Minimum information</th><th>Purpose</th></tr></thead><tbody><tr><td>Master Document Checklist</td><td>Required evidence for each transaction.</td><td>Confirms completeness before filing or review.</td></tr><tr><td>Procurement Tracker</td><td>PR, RFQ, Quotes, CBA, PO, Contract, Delivery, Invoice and Payment.</td><td>Tracks the complete procurement trail.</td></tr><tr><td>Payment Tracker</td><td>Payment date, supplier/staff, amount, currency, project, voucher, bank reference and supporting status.</td><td>Tracks payment evidence and clearance.</td></tr><tr><td>Advances Tracker</td><td>Employee, amount, date, purpose, settlement deadline, settled amount and outstanding balance.</td><td>Monitors open advances until settlement.</td></tr><tr><td>BvA Tracker</td><td>Budget, actual, variance, percentage variance, explanation and action.</td><td>Supports Budget vs Actual monitoring.</td></tr><tr><td>Donor Compliance Matrix</td><td>Donor requirements and evidence status.</td><td>Tracks compliance obligations for each donor.</td></tr><tr><td>Contract Tracker</td><td>Start date, end date, value, payments, balance and renewal.</td><td>Monitors contractual commitments.</td></tr><tr><td>Asset Register</td><td>Asset identification and custody information.</td><td>Tracks all assets.</td></tr><tr><td>Staff Allocation Matrix</td><td>Staff and project allocation.</td><td>Links staff time or cost to projects.</td></tr><tr><td>Audit Issues Tracker</td><td>Finding, root cause, corrective action, responsible person, deadline and status.</td><td>Follows audit actions through closure.</td></tr></tbody></table>
<blockquote><strong>Control principle:</strong> Each tracker should have a clear owner, a defined update frequency and an evidence link where relevant.</blockquote>'''

replacements = {4: section4, 27: section27}
current = None
for i, line in enumerate(lines):
    if '"number": ' in line:
        try:
            current = int(line.split('"number": ')[1].split(',')[0])
        except ValueError:
            current = None
    if current in replacements and '"bodyEn":' in line:
        indent = line[:len(line)-len(line.lstrip())]
        lines[i] = indent + '"bodyEn": ' + json.dumps(replacements[current], ensure_ascii=False) + (',' if line.rstrip().endswith(',') else '')
        current = None

path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('updated English sections 4 and 27 with consistent headings, lists, rules, and tables')
