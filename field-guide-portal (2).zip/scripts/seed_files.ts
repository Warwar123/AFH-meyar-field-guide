import { guideFiles } from "../drizzle/schema";
import { getDb } from "../server/db";

const initialTemplates = [
  {
    title: "نموذج طلب الشراء المعتمد (PR Form)",
    fileName: "standard_purchase_requisition_template.xlsx",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 45200,
    fileKey: "templates/pr_form.xlsx",
    url: "#pr-template",
    category: "template" as const,
    sectionId: 2
  },
  {
    title: "مصفوفة مقارنة عروض الأسعار (CBA - Bid Analysis)",
    fileName: "bid_analysis_matrix.xlsx",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 58300,
    fileKey: "templates/bid_analysis.xlsx",
    url: "#cba-template",
    category: "template" as const,
    sectionId: 4
  },
  {
    title: "سجل الأصول والمخزون الميداني (Asset & Inventory Register)",
    fileName: "field_asset_register.xlsx",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 72100,
    fileKey: "templates/asset_register.xlsx",
    url: "#asset-register",
    category: "checklist" as const,
    sectionId: 18
  },
  {
    title: "قائمة تحقق اكتمال ملف الصرف والتدقيق (Payment Audit Checklist)",
    fileName: "payment_readiness_checklist.pdf",
    mimeType: "application/pdf",
    size: 114000,
    fileKey: "checklists/audit_checklist.pdf",
    url: "#audit-checklist",
    category: "checklist" as const,
    sectionId: 1
  },
  {
    title: "سياسة السلف النثرية والعهد الميدانية (Petty Cash Policy & Form)",
    fileName: "petty_cash_field_guidelines.pdf",
    mimeType: "application/pdf",
    size: 132000,
    fileKey: "policies/petty_cash.pdf",
    url: "#petty-cash-policy",
    category: "policy" as const,
    sectionId: 12
  }
];

async function seedFiles() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL unavailable");

  const existing = await db.select({ id: guideFiles.id }).from(guideFiles).limit(1);
  if (existing.length === 0) {
    for (const f of initialTemplates) {
      await db.insert(guideFiles).values({
        title: f.title,
        fileName: f.fileName,
        mimeType: f.mimeType,
        size: f.size,
        fileKey: f.fileKey,
        url: f.url,
        category: f.category,
        sectionId: f.sectionId,
        uploadedBy: 1
      });
    }
    console.log(`Seeded ${initialTemplates.length} default guide templates/files.`);
  } else {
    console.log("Guide files already exist.");
  }
  process.exit(0);
}

seedFiles().catch((err) => {
  console.error("Failed seeding files:", err);
  process.exit(1);
});
