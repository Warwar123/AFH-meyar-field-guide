import { asc } from "drizzle-orm";
import { guideSections } from "../drizzle/schema";
import { getDb } from "../server/db";
const db = await getDb();
if (!db) throw new Error("DATABASE_URL unavailable");
const rows = await db.select({ number: guideSections.number, title: guideSections.title, titleEn: guideSections.titleEn, summary: guideSections.summary, summaryEn: guideSections.summaryEn, bodyStart: guideSections.body, bodyEnStart: guideSections.bodyEn }).from(guideSections).orderBy(asc(guideSections.number)).limit(3);
for (const row of rows) console.log(JSON.stringify({ number: row.number, title: row.title, titleEn: row.titleEn, summary: row.summary?.slice(0,80), summaryEn: row.summaryEn?.slice(0,80), body: row.bodyStart?.slice(0,80), bodyEn: row.bodyEnStart?.slice(0,80) }));
process.exit(0);
