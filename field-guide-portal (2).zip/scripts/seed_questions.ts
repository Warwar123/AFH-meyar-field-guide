import { questions } from "../drizzle/schema";
import { getDb } from "../server/db";

const initialQA = [
  {
    name: "سارة المهدي - مسؤول مالي ميداني",
    email: "sarah.m@example.org",
    kind: "question" as const,
    question: "عند تنفيذ مشتريات عاجلة خلال الاستجابة الطارئة، هل يمكن تجاوز طلب عروض الأسعار (RFQ) الثلاثة؟",
    sectionSlug: "section-2",
    status: "answered" as const,
    answer: "في حالات الطوارئ القصوى المصنفة رسمياً، يمكن الاستثناء بموجب مذكرة تبرير موقعة (Single Source Justification) معتمدة من مدير المكتب الإقليمي والمدير المالي، مع إرفاق سجل أسعار السوق المرجعي لإثبات معقولية التكلفة.",
    answeredBy: 1,
    answeredAt: new Date(Date.now() - 86400000 * 2)
  },
  {
    name: "م. خالد الراشد - منسق برامج",
    email: "khaled.r@example.org",
    kind: "question" as const,
    question: "ما الفرق الأساسي بين دور قسم البرامج وقسم المالية في اعتماد سند الصرف النهائي؟",
    sectionSlug: "section-3",
    status: "answered" as const,
    answer: "قسم البرامج يؤكد الإنجاز الفني ومطابقة المخرجات لنطاق العمل والشروط المرجعية (ToR)، بينما قسم المالية يتحقق من الأهلية الحسابية وتوفر التغطية بالموازنة واكتمال الدورة المستندية والامتثال الضريبي والمصرفي.",
    answeredBy: 1,
    answeredAt: new Date(Date.now() - 86400000 * 5)
  },
  {
    name: "هدى العلي - إدارة الموارد البشرية",
    email: "huda.ali@example.org",
    kind: "comment" as const,
    question: "نشكركم على وضوح مصفوفة فصل المهام (SoD) في الباب الثالث، ونقترح إضافة تنبيه خاص بالمكاتب الصغيرة ذات الكادر المحدود.",
    sectionSlug: "section-3",
    status: "answered" as const,
    answer: "تم اعتماد مقترحك وتمت إضافة ضوابط رقابية تعويضية (Compensating Controls) للمكاتب التي يقل عدد موظفيها عن 4 أشخاص لتفادي تضارب الصلاحيات.",
    answeredBy: 1,
    answeredAt: new Date(Date.now() - 86400000 * 8)
  }
];

async function seedQA() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL unavailable");

  const existing = await db.select({ id: questions.id }).from(questions).limit(1);
  if (existing.length === 0) {
    for (const q of initialQA) {
      await db.insert(questions).values({
        name: q.name,
        email: q.email,
        kind: q.kind,
        question: q.question,
        sectionSlug: q.sectionSlug,
        status: q.status,
        answer: q.answer,
        answeredBy: q.answeredBy,
        answeredAt: q.answeredAt
      });
    }
    console.log(`Seeded ${initialQA.length} Q&A items.`);
  } else {
    console.log("Q&A already seeded.");
  }
  process.exit(0);
}

seedQA().catch((err) => {
  console.error(err);
  process.exit(1);
});
