import { portalContent } from "../drizzle/schema";
import { getDb } from "../server/db";

const initialGlossary = [
  {
    id: "po",
    termAr: "أمر الشراء (PO)",
    termEn: "Purchase Order (PO)",
    definitionAr: "وثيقة قانونية ورسمية تصدر لقسم المشتريات أو المورد تتضمن تفاصيل الأصناف، الكميات، الأسعار المعتمدة وشروط التسليم.",
    definitionEn: "A formal legally binding document issued to a vendor detailing items, quantities, agreed prices, and delivery terms.",
    objectiveAr: "ضبط الالتزام المالي والتعاقدي وتحديد شروط التوريد بدقة.",
    objectiveEn: "Establish financial and contractual commitment and define exact supply terms."
  },
  {
    id: "pr",
    termAr: "طلب الشراء (PR)",
    termEn: "Purchase Requisition (PR)",
    definitionAr: "طلب داخلي ينشئه القسم الطالب لتحديد الحاجة للمواد أو الخدمات قبل بدء إجراءات الشراء أو التعاقد.",
    definitionEn: "An internal request created by the requesting department specifying needed goods or services prior to procurement.",
    objectiveAr: "التحقق من اعتماد النشاط وتوفر الموازنة قبل فتح ملف المشتريات.",
    objectiveEn: "Verify activity approval and budget availability before committing resources."
  },
  {
    id: "rfq",
    termAr: "طلب عروض الأسعار (RFQ)",
    termEn: "Request for Quotation (RFQ)",
    definitionAr: "دعوة رسمية موجهة للموردين المؤهلين لتقديم عروضهم الفنية والمالية وفق مواصفات موحدة ومحددة مسبقاً.",
    definitionEn: "A formal invitation sent to qualified vendors to provide commercial bids based on standardized specifications.",
    objectiveAr: "ضمان الشفافية، العدالة والمنافسة السعرية للحصول على أفضل قيمة مقابل المال.",
    objectiveEn: "Ensure transparency, fair competition, and optimal value for money."
  },
  {
    id: "grn",
    termAr: "إشعار استلام البضائع (GRN)",
    termEn: "Goods Received Note (GRN)",
    definitionAr: "وثيقة تصدرها لجنة الاستلام أو مسؤول المستودع تؤكد فحص واستلام المواد مطابقة للمواصفات والكميات المطلوبة.",
    definitionEn: "A receipt voucher issued by warehouse or inspection committee confirming items were received per specs.",
    objectiveAr: "إثبات واقعة التسليم الفعلي قبل الموافقة على الدفع للمورد.",
    objectiveEn: "Prove physical delivery and quality compliance before processing vendor payment."
  },
  {
    id: "tor",
    termAr: "الشروط المرجعية (ToR)",
    termEn: "Terms of Reference (ToR)",
    definitionAr: "وثيقة تحدد نطاق العمل، الأهداف، المخرجات، والجدول الزمني لأي خدمة استشارية أو عمل تعاقدي.",
    definitionEn: "A document detailing scope of work, objectives, deliverables, and timelines for service contracts.",
    objectiveAr: "توحيد التوقعات وإلزام الاستشاري أو مقدم الخدمة بمخرجات قابلة للقياس والتقييم.",
    objectiveEn: "Standardize deliverables, deliverables criteria, and performance milestones."
  },
  {
    id: "budget-verification",
    termAr: "مطابقة الموازنة (Budget Verification)",
    termEn: "Budget Verification",
    definitionAr: "إجراء رقابي مالي يتحقق من وجود بند مالي معتمد ورصيد كافٍ لتغطية الالتزام المقترح.",
    definitionEn: "A financial control check verifying adequate approved budget line balance exists for the commitment.",
    objectiveAr: "منع الإنفاق خارج بنود الموازنة وتفادي العجز أو التكاليف غير المؤهلة لدى المانحين.",
    objectiveEn: "Prevent budget overrun and donor unallowable costs."
  },
  {
    id: "segregation-of-duties",
    termAr: "فصل المهام والمسؤوليات (Segregation of Duties)",
    termEn: "Segregation of Duties (SoD)",
    definitionAr: "مبدأ رقابي داخلي يقضي بعدم تمكين شخص واحد من بدء المعاملة، والموافقة عليها، وتنفيذ الدفع، والتحقق منها.",
    definitionEn: "Internal control principle ensuring no single individual initiates, approves, disburses, and reconciles a transaction.",
    objectiveAr: "الحد من مخاطر الاحتيال، الأخطاء غير المقصودة، وتضارب المصالح في المكاتب الميدانية.",
    objectiveEn: "Mitigate fraud risks, operational errors, and conflicts of interest."
  },
  {
    id: "payment-voucher",
    termAr: "سند الصرف (Payment Voucher)",
    termEn: "Payment Voucher (PV)",
    definitionAr: "مستند محاسبي رسمي يوثق تفويض الصرف والخصم من الحساب البنكي أو الصندوق مدعماً بكافة المرفقات الثبوتية.",
    definitionEn: "An official accounting voucher authorizing bank disbursement backed by complete supporting evidence.",
    objectiveAr: "إثبات القيد المحاسبي وحيازة كافة المرفقات الثبوتية المؤيدة للمعاملة.",
    objectiveEn: "Provide audit-ready proof of disbursement and complete backing evidence."
  }
];

async function seedGlossary() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL is not available");

  for (const item of initialGlossary) {
    const key = `glossary.${item.id}`;
    const value = JSON.stringify(item);
    await db.insert(portalContent).values({
      contentKey: key,
      valueAr: value,
      valueEn: value,
      format: "text",
      updatedBy: 1
    }).onDuplicateKeyUpdate({
      set: { valueAr: value, valueEn: value }
    });
  }

  console.log(`Seeded ${initialGlossary.length} glossary terms successfully.`);
  process.exit(0);
}

seedGlossary().catch((err) => {
  console.error("Failed to seed glossary:", err);
  process.exit(1);
});
