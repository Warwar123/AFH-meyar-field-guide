import { ShieldAlert, ArrowRight } from "lucide-react";
import { Link } from "wouter";
export default function AccessDenied() {
  const isAr = document.documentElement.lang === "ar";
  return <main className="access-denied-page" dir={isAr ? "rtl" : "ltr"}><div className="access-denied-card"><ShieldAlert size={46} /><h1>{isAr ? "الوصول غير مصرح" : "Access denied"}</h1><p>{isAr ? "هذه المنطقة مخصصة لحساب مالك البوابة المعتمد فقط. سجّل الدخول بالحساب المعتمد أو تواصل مع مالك الموقع." : "This area is reserved for the configured portal owner. Sign in with the approved account or contact the site owner."}</p><Link href="/"><ArrowRight size={16} /> {isAr ? "العودة إلى البوابة" : "Back to portal"}</Link></div></main>;
}
