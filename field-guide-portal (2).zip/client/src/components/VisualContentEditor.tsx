import { useEffect, useMemo, useState } from "react";
import { Check, MousePointer2, RotateCcw, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

type Lang = "ar" | "en";
type ContentItem = { contentKey: string; valueAr: string; valueEn: string; format: "text" | "rich" };
type Props = { isAr: boolean; lang: Lang; defaults: Record<string, { ar: string; en: string }>; saved: ContentItem[]; onSave: (items: ContentItem[], changeType?: "save" | "default") => void; onSaveSection?: (sectionId: number, patch: { body?: string; bodyEn?: string }) => void; onClose: () => void };
type Target = { key: string; element: HTMLElement; value: string; rect: DOMRect; tableCell?: boolean; sectionId?: number };

export function VisualContentEditor({ isAr, lang, defaults, saved, onSave, onSaveSection, onClose }: Props) {
  const [target, setTarget] = useState<Target | null>(null);
  const [draft, setDraft] = useState("");
  const map = useMemo(() => {
    const result = new Map<string, ContentItem>();
    Object.entries(defaults).forEach(([contentKey, value]) => result.set(contentKey, { contentKey, valueAr: value.ar, valueEn: value.en, format: "text" }));
    saved.forEach((item) => result.set(item.contentKey, item));
    return result;
  }, [defaults, saved]);
  useEffect(() => {
    const root = document.querySelector(".site-shell");
    if (!root) return;
    const elements = Array.from(root.querySelectorAll<HTMLElement>("h1,h2,h3,h4,p,span,b,small,button,a,label,th,td"));
    elements.forEach((element) => {
      if (element.closest(".visual-content-toolbar, .owner-settings-overlay, input, textarea, select")) return;
      const text = element.childElementCount === 0 ? element.textContent?.trim() || "" : "";
      if (!text) return;
      const match = Array.from(map.values()).find((item) => (lang === "ar" ? item.valueAr : item.valueEn).trim() === text);
      const cell = element.matches("th,td") ? element.closest<HTMLElement>(".guide-body") : null;
      if (match) { element.dataset.visualContentKey = match.contentKey; element.classList.add("visual-editable-target"); }
      else if (cell?.dataset.sectionId) { element.dataset.visualTableCell = "true"; element.classList.add("visual-editable-target"); }
    });
    const onClick = (event: Event) => {
      const mouseEvent = event as MouseEvent;
      const element = (mouseEvent.target as HTMLElement).closest<HTMLElement>("[data-visual-content-key], [data-visual-table-cell]");
      if (!element || element.closest(".visual-content-toolbar, .visual-content-popover")) return;
      mouseEvent.preventDefault(); mouseEvent.stopPropagation();
      const key = element.dataset.visualContentKey || "";
      const item = map.get(key);
      const isTableCell = element.dataset.visualTableCell === "true";
      if (!item && !isTableCell) return;
      const sectionId = Number(element.closest<HTMLElement>(".guide-body")?.dataset.sectionId || 0) || undefined;
      setTarget({ key, element, value: item ? (lang === "ar" ? item.valueAr : item.valueEn) : element.textContent?.trim() || "", rect: element.getBoundingClientRect(), tableCell: isTableCell, sectionId });
      setDraft(item ? (lang === "ar" ? item.valueAr : item.valueEn) : element.textContent?.trim() || "");
    };
    root.addEventListener("click", onClick, true);
    return () => { root.removeEventListener("click", onClick, true); elements.forEach((element) => { element.classList.remove("visual-editable-target"); delete element.dataset.visualContentKey; delete element.dataset.visualTableCell; }); };
  }, [lang, map]);
  const save = () => {
    if (!target) return;
    if (target.tableCell && target.sectionId && onSaveSection) {
      target.element.textContent = draft;
      const body = target.element.closest<HTMLElement>(".guide-body");
      onSaveSection(target.sectionId, lang === "ar" ? { body: body?.innerHTML || "" } : { bodyEn: body?.innerHTML || "" });
      setTarget(null);
      return;
    }
    const current = map.get(target.key); if (!current) return;
    onSave([{ ...current, [lang === "ar" ? "valueAr" : "valueEn"]: draft }]);
    target.element.textContent = draft;
    setTarget(null);
  };
  const tableAction = (action: "addRow" | "deleteRow" | "addColumn" | "deleteColumn") => {
    if (!target?.tableCell || !target.sectionId || !onSaveSection) return;
    const cell = target.element.closest<HTMLTableCellElement>("td,th");
    const table = cell?.closest<HTMLTableElement>("table");
    if (!cell || !table) return;
    const row = cell.closest<HTMLTableRowElement>("tr");
    if (action === "addRow" && row) { const next = row.cloneNode(true) as HTMLTableRowElement; Array.from(next.cells).forEach((item) => { item.textContent = isAr ? "أضف البيانات هنا" : "Add content"; }); row.parentElement?.insertBefore(next, row.nextSibling); }
    if (action === "deleteRow" && row && table.rows.length > 2) row.remove();
    if (action === "addColumn") { const index = cell.cellIndex; Array.from(table.rows).forEach((current) => { const newCell = document.createElement(current.parentElement?.tagName.toLowerCase() === "thead" ? "th" : "td"); newCell.textContent = isAr ? "أضف البيانات هنا" : "Add content"; current.insertBefore(newCell, current.cells[index + 1] || null); }); }
    if (action === "deleteColumn" && table.rows[0].cells.length > 1) Array.from(table.rows).forEach((current) => current.cells[cell.cellIndex]?.remove());
    const body = target.element.closest<HTMLElement>(".guide-body");
    onSaveSection(target.sectionId, lang === "ar" ? { body: body?.innerHTML || "" } : { bodyEn: body?.innerHTML || "" });
    setTarget(null);
  };
  const reset = () => {
    if (!target) return;
    if (target.tableCell) { setTarget(null); return; }
    const fallback = defaults[target.key]?.[lang]; if (fallback === undefined) return;
    const current = map.get(target.key); if (!current) return;
    setDraft(fallback); target.element.textContent = fallback;
    onSave([{ ...current, [lang === "ar" ? "valueAr" : "valueEn"]: fallback }], "default");
    setTarget(null);
  };
  return <>
    <div className="visual-content-toolbar" role="toolbar" aria-label={isAr ? "أدوات التعديل البصري" : "Visual editing tools"}><span><MousePointer2 size={15} /> {isAr ? "انقر على أي نص قابل للتحرير" : "Click any editable text"}</span><small>{isAr ? "يتم حفظ كل تعديل في سجل النسخ" : "Every edit is added to version history"}</small><button type="button" onClick={onClose} aria-label={isAr ? "إغلاق التعديل البصري" : "Close visual editor"}><X size={16} /></button></div>
    {target && <div className="visual-content-popover" style={{ top: Math.min(Math.max(target.rect.bottom + 10, 76), window.innerHeight - 285), left: Math.min(Math.max(target.rect.left, 12), window.innerWidth - 380) }} role="dialog" aria-label={isAr ? "تحرير النص" : "Edit text"}><div className="visual-popover-head"><b>{isAr ? "تحرير مباشر" : "Live edit"}</b><span>{target.key}</span></div><Textarea autoFocus dir={lang === "ar" ? "rtl" : "ltr"} value={draft} onChange={(event) => setDraft(event.target.value)} /><div className="visual-table-actions">{target.tableCell && <><Button type="button" variant="outline" onClick={() => tableAction("addRow")}>{isAr ? "إضافة صف" : "Add row"}</Button><Button type="button" variant="outline" onClick={() => tableAction("deleteRow")}>{isAr ? "حذف صف" : "Delete row"}</Button><Button type="button" variant="outline" onClick={() => tableAction("addColumn")}>{isAr ? "إضافة عمود" : "Add column"}</Button><Button type="button" variant="outline" onClick={() => tableAction("deleteColumn")}>{isAr ? "حذف عمود" : "Delete column"}</Button></>}</div><div className="visual-popover-actions"><Button type="button" variant="outline" className="bg-white" onClick={reset}><RotateCcw size={14} /> {isAr ? "الافتراضي" : "Default"}</Button><Button type="button" className="action-dark" onClick={save}><Save size={14} /> {isAr ? "حفظ" : "Save"}</Button></div></div>}
  </>;
}
