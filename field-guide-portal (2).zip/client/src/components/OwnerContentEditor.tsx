import { useEffect, useMemo, useState } from "react";
import { AlignCenter, AlignLeft, AlignRight, Bold, Italic, Palette, Save, Search, Sparkles, Type, Underline, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

type Language = "ar" | "en";
type Tone = "formal" | "creative" | "concise";
type ContentItem = { contentKey: string; valueAr: string; valueEn: string; format: "text" | "rich" };
type Props = { isAr: boolean; pending?: boolean; defaults: Record<string, { ar: string; en: string }>; saved: ContentItem[]; onClose: () => void; onSave: (items: ContentItem[]) => void; onResetFormatting?: () => void; onSuggest?: (text: string, language: Language, action: "improve" | "rewrite" | "shorten", tone: Tone) => Promise<string> };

const labels: Record<string, { ar: string; en: string }> = {
  hero: { ar: "العنوان الرئيسي", en: "Hero heading" }, heroDesc: { ar: "وصف الصفحة الرئيسي", en: "Hero description" }, libraryTitle: { ar: "عنوان المكتبة", en: "Library title" }, libraryDesc: { ar: "وصف المكتبة", en: "Library description" }, filesTitle: { ar: "عنوان الملفات", en: "Files title" }, filesDesc: { ar: "وصف الملفات", en: "Files description" }, questionTitle: { ar: "عنوان الاستفسارات", en: "Questions title" }, questionDesc: { ar: "وصف الاستفسارات", en: "Questions description" }, aboutTitle: { ar: "عنوان عن البوابة", en: "About title" }, footer: { ar: "تذييل الموقع", en: "Site footer" },
};

export function OwnerContentEditor({ isAr, pending, defaults, saved, onClose, onSave, onResetFormatting, onSuggest }: Props) {
  const initial = useMemo(() => {
    const stored = new Map(saved.map((item) => [item.contentKey, item]));
    return Object.entries(defaults).map(([contentKey, value]) => stored.get(contentKey) || { contentKey, valueAr: value.ar, valueEn: value.en, format: "text" as const });
  }, [defaults, saved]);
  const [items, setItems] = useState<ContentItem[]>(initial);
  const [activeKey, setActiveKey] = useState(Object.keys(defaults)[0] || "");
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<Language>(isAr ? "ar" : "en");
  const [fontFamily, setFontFamily] = useState("Arial, sans-serif");
  const [fontSize, setFontSize] = useState("16px");
  const [lineHeight, setLineHeight] = useState("1.7");
  const [textColor, setTextColor] = useState("#173b4c");
  const [fontWeight, setFontWeight] = useState("700");
  const [fontStyle, setFontStyle] = useState("normal");
  const [textAlign, setTextAlign] = useState("start");
  const [textDecoration, setTextDecoration] = useState("none");
  const [aiAction, setAiAction] = useState<"improve" | "rewrite" | "shorten">("improve");
  const [aiTone, setAiTone] = useState<Tone>("formal");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState("");
  useEffect(() => {
    setItems(initial);
    const styles = new Map(saved.map((item) => [item.contentKey, item.valueAr]));
    setFontFamily(styles.get("__style.fontFamily") || "Arial, sans-serif");
    setFontSize(styles.get("__style.fontSize") || "16px");
    setLineHeight(styles.get("__style.lineHeight") || "1.7");
    setTextColor(styles.get("__style.textColor") || "#173b4c");
    setFontWeight(styles.get("__style.fontWeight") || "700");
    setFontStyle(styles.get("__style.fontStyle") || "normal");
    setTextAlign(styles.get("__style.textAlign") || "start");
    setTextDecoration(styles.get("__style.textDecoration") || "none");
  }, [initial, saved]);
  const filtered = Object.keys(defaults).filter((key) => `${key} ${labels[key]?.ar || ""} ${labels[key]?.en || ""} ${(items.find((item) => item.contentKey === key)?.valueAr || "")}`.toLowerCase().includes(search.toLowerCase()));
  const active = items.find((item) => item.contentKey === activeKey) || items[0];
  const updateActive = (field: "valueAr" | "valueEn", value: string) => setItems((current) => current.map((item) => item.contentKey === active?.contentKey ? { ...item, [field]: value } : item));
  const save = () => onSave([...items, ...[
    ["__style.fontFamily", fontFamily], ["__style.fontSize", fontSize], ["__style.lineHeight", lineHeight], ["__style.textColor", textColor], ["__style.fontWeight", fontWeight], ["__style.fontStyle", fontStyle], ["__style.textAlign", textAlign], ["__style.textDecoration", textDecoration],
  ].map(([contentKey, value]) => ({ contentKey, valueAr: value, valueEn: value, format: "text" as const }))]);
  const askAssistant = async () => {
    if (!active || !onSuggest) return;
    const text = tab === "ar" ? active.valueAr : active.valueEn;
    if (!text.trim()) return;
    setAiLoading(true); setAiSuggestion("");
    try { setAiSuggestion(await onSuggest(text, tab, aiAction, aiTone)); } finally { setAiLoading(false); }
  };
  const applySuggestion = () => { if (aiSuggestion) { updateActive(tab === "ar" ? "valueAr" : "valueEn", aiSuggestion); setAiSuggestion(""); } };
  return <div className="owner-settings-overlay content-editor-overlay" role="dialog" aria-modal="true" aria-labelledby="content-editor-title">
    <div className="owner-content-editor">
      <header className="owner-settings-head"><div><span className="eyebrow"><Type size={14} /> {isAr ? "تحرير شامل للموقع" : "Full site editor"}</span><h3 id="content-editor-title">{isAr ? "تحرير جميع النصوص والتنسيق" : "Edit all site text and formatting"}</h3></div><button type="button" className="icon-close" onClick={onClose} aria-label={isAr ? "إغلاق" : "Close"}><X size={18} /></button></header>
      <div className="content-editor-toolbar"><label className="content-editor-select"><span>{isAr ? "اللغة" : "Language"}</span><select value={tab} onChange={(e) => setTab(e.target.value as Language)}><option value="ar">العربية</option><option value="en">English</option></select></label><label className="content-editor-select"><span>{isAr ? "نوع الخط" : "Font"}</span><select value={fontFamily} onChange={(e) => setFontFamily(e.target.value)}><option>Arial, sans-serif</option><option>Tahoma, sans-serif</option><option>Georgia, serif</option><option>Verdana, sans-serif</option></select></label><label className="content-editor-select"><span>{isAr ? "حجم الخط" : "Size"}</span><select value={fontSize} onChange={(e) => setFontSize(e.target.value)}><option>14px</option><option>16px</option><option>18px</option><option>20px</option><option>24px</option></select></label><label className="content-editor-select"><span>{isAr ? "تباعد الأسطر" : "Line height"}</span><select value={lineHeight} onChange={(e) => setLineHeight(e.target.value)}><option value="1.4">1.4</option><option value="1.7">1.7</option><option value="2">2.0</option></select></label><label className="content-editor-select"><span>{isAr ? "السُمك" : "Weight"}</span><select value={fontWeight} onChange={(e) => setFontWeight(e.target.value)}><option value="400">عادي / Regular</option><option value="600">متوسط / Medium</option><option value="700">غامق / Bold</option><option value="900">ثقيل / Black</option></select></label><label className="content-color"><Palette size={15} /><input type="color" value={textColor} onChange={(e) => setTextColor(e.target.value)} /></label><button type="button" className="format-toolbar-button" onClick={() => setFontStyle((value) => value === "normal" ? "italic" : "normal")}><Italic size={15} /></button><button type="button" className="format-toolbar-button" onClick={() => setTextAlign((value) => value === "start" ? "center" : value === "center" ? "end" : "start")}><AlignCenter size={15} /></button></div>
      <div className="content-editor-body"><aside className="content-key-list"><div className="content-search"><Search size={15} /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isAr ? "ابحث عن نص أو مفتاح..." : "Find text or key..."} /></div>{filtered.map((key) => <button key={key} className={key === activeKey ? "active" : ""} onClick={() => { setActiveKey(key); setAiSuggestion(""); }}><b>{labels[key]?.[isAr ? "ar" : "en"] || key}</b><small>{key}</small></button>)}</aside><section className="content-edit-form">{active && <><div className="content-edit-heading"><div><span>{labels[active.contentKey]?.[isAr ? "ar" : "en"] || active.contentKey}</span><small>{active.contentKey}</small></div><div className="format-buttons"><button type="button" title="Bold" onClick={() => setFontWeight((value) => value === "900" ? "400" : "900")}><Bold size={16} /></button><button type="button" title="Italic" onClick={() => setFontStyle((value) => value === "italic" ? "normal" : "italic")}><Italic size={16} /></button><button type="button" title="Underline" onClick={() => setTextDecoration((value) => value === "underline" ? "none" : "underline")}><Underline size={16} /></button><button type="button" title="Align right" onClick={() => setTextAlign("end")}><AlignRight size={16} /></button><button type="button" title="Align center" onClick={() => setTextAlign("center")}><AlignCenter size={16} /></button><button type="button" title="Align left" onClick={() => setTextAlign("start")}><AlignLeft size={16} /></button></div></div><Textarea dir={tab === "ar" ? "rtl" : "ltr"} className="content-large-textarea" value={tab === "ar" ? active.valueAr : active.valueEn} onChange={(e) => { updateActive(tab === "ar" ? "valueAr" : "valueEn", e.target.value); setAiSuggestion(""); }} /><div className="ai-editor-box"><div><b><Sparkles size={15} /> {isAr ? "مساعد الصياغة الذكي" : "AI writing assistant"}</b><small>{isAr ? "اقتراح غير ملزم؛ راجعه قبل الحفظ." : "Optional suggestion; review before saving."}</small></div><div className="ai-editor-controls"><select value={aiTone} onChange={(e) => setAiTone(e.target.value as Tone)}><option value="formal">{isAr ? "رسمي" : "Formal"}</option><option value="creative">{isAr ? "إبداعي" : "Creative"}</option><option value="concise">{isAr ? "مختصر" : "Concise"}</option></select><select value={aiAction} onChange={(e) => setAiAction(e.target.value as typeof aiAction)}><option value="improve">{isAr ? "تحسين لغوي" : "Improve language"}</option><option value="rewrite">{isAr ? "إعادة صياغة" : "Rewrite"}</option><option value="shorten">{isAr ? "اختصار" : "Shorten"}</option></select><Button type="button" className="ai-suggest-button" disabled={aiLoading || !onSuggest} onClick={askAssistant}><Sparkles size={14} /> {aiLoading ? (isAr ? "جارٍ الاقتراح..." : "Thinking...") : (isAr ? "اقترح" : "Suggest")}</Button></div>{aiSuggestion && <div className="ai-suggestion" dir={tab === "ar" ? "rtl" : "ltr"}><p>{aiSuggestion}</p><Button type="button" className="action-dark" onClick={applySuggestion}>{isAr ? "استخدام الاقتراح" : "Use suggestion"}</Button></div>}</div></>}</section></div>
      <footer className="settings-actions"><span className="content-edit-count">{Object.keys(defaults).length} {isAr ? "عنصرًا قابلًا للتحرير" : "editable content items"}</span><div><Button type="button" variant="ghost" disabled={pending} onClick={onResetFormatting}>{isAr ? "استعادة التنسيق الافتراضي" : "Reset default formatting"}</Button><Button type="button" variant="outline" className="bg-white" onClick={onClose}>{isAr ? "إلغاء" : "Cancel"}</Button><Button type="button" className="action-dark" disabled={pending} onClick={save}><Save size={15} /> {pending ? (isAr ? "جارٍ الحفظ..." : "Saving...") : (isAr ? "حفظ كل النصوص" : "Save all text")}</Button></div></footer>
    </div>
  </div>;
}
