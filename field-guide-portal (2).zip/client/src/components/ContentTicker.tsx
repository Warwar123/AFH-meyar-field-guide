import { useEffect, useMemo, useRef, useState } from "react";
import { Pause, Play, Radio, Settings2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

type Lang = "ar" | "en";
type Direction = "forward" | "reverse";
type Filter = "all" | "finance" | "operations" | "hr" | "programme" | "donor" | "logistics";
type Section = { number: number; title: string; titleEn?: string | null; body: string; bodyEn?: string | null };
type Props = { sections: Section[]; lang: Lang; isAr: boolean; isAdmin?: boolean };
const stripHtml = (value: string) => value.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
const settingsKey = "guide-ticker-settings";
const filterTerms: Record<Exclude<Filter, "all">, string[]> = { finance: ["finance", "financial", "budget", "الموازنة", "المالية"], operations: ["operation", "procurement", "العمليات", "المشتريات"], hr: ["hr", "payroll", "recruit", "human resource", "الموارد البشرية"], programme: ["programme", "program", "activity", "البرامج", "النشاط"], donor: ["donor", "مانح", "المانحين"], logistics: ["logistics", "asset", "travel", "اللوجستيات", "الأصول"] };

export function ContentTicker({ sections, lang, isAr, isAdmin }: Props) {
  const [speed, setSpeed] = useState(2000);
  const [direction, setDirection] = useState<Direction>("forward");
  const [paused, setPaused] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");
  const [textFilter, setTextFilter] = useState("");
  const [controlsOpen, setControlsOpen] = useState(false);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const settingsHydrated = useRef(false);
  const lastVisibleItems = useRef<string[]>([]);
  const tickerQuery = trpc.ticker.get.useQuery({ language: lang });
  const tickerSave = trpc.ticker.save.useMutation();
  const controlsRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    setSettingsLoaded(false);
    settingsHydrated.current = false;
    if (!tickerQuery.isFetched) return;
    const saved = tickerQuery.data;
    setSpeed(saved?.speed && saved.speed >= 300 && saved.speed <= 2000 ? saved.speed : 2000);
    setDirection(saved?.direction === "reverse" ? "reverse" : "forward");
    setPaused(saved ? saved.paused === 1 : false);
    setFilter(saved?.filter && Object.prototype.hasOwnProperty.call({ all: true, finance: true, operations: true, hr: true, programme: true, donor: true, logistics: true }, saved.filter) ? saved.filter as Filter : "all");
    setTextFilter(saved?.textFilter || "");
    settingsHydrated.current = true;
    setSettingsLoaded(true);
  }, [isAdmin, lang, tickerQuery.data, tickerQuery.isFetched]);
  useEffect(() => {
    if (settingsLoaded && settingsHydrated.current && isAdmin && !tickerQuery.isFetching) tickerSave.mutate({ language: lang, speed, direction, paused, filter, textFilter });
  }, [lang, settingsLoaded, isAdmin, speed, direction, paused, filter, textFilter]);
  useEffect(() => { setControlsOpen(false); }, [lang]);
  useEffect(() => {
    const closeOnOutside = (event: PointerEvent) => {
      if (controlsRef.current && !controlsRef.current.contains(event.target as Node)) setControlsOpen(false);
    };
    document.addEventListener("pointerdown", closeOnOutside);
    return () => document.removeEventListener("pointerdown", closeOnOutside);
  }, []);
  const items = useMemo(() => sections.flatMap((section) => {
    const title = lang === "ar" ? section.title : section.titleEn || section.title;
    const body = (lang === "ar" ? section.body : section.bodyEn || section.body) || section.title || "";
    const source = `${title} ${body}`.toLowerCase();
    const categoryMatch = filter === "all" || filterTerms[filter].some((term) => source.includes(term.toLowerCase()));
    const query = textFilter.trim().toLowerCase();
    const textMatch = !query || source.includes(query);
    if (!categoryMatch || !textMatch) return [];
    return stripHtml(body).split(/[.!؟。]/).map((value) => value.trim()).filter((value) => value.length > 35).slice(0, 3).map((snippet) => `${String(section.number).padStart(2, "0")} · ${title}: ${snippet}`);
  }), [filter, lang, sections, textFilter]);
  const fallbackItems = sections.flatMap((section) => {
    const title = lang === "ar" ? section.title : section.titleEn || section.title;
    const selectedBody = lang === "ar" ? section.body : section.bodyEn || section.body;
    const body = stripHtml(selectedBody || (lang === "ar" ? section.bodyEn : section.body) || "");
    const sentences = body.split(/[.!؟。؛\n]/).map((value) => value.trim()).filter(Boolean);
    const usable = sentences.filter((value) => value.length > 20);
    const snippets = usable.length ? usable.slice(0, 3) : [body || title];
    return snippets.map((snippet) => `${String(section.number).padStart(2, "0")} · ${title}: ${snippet}`);
  });
  const nextVisibleItems = items.length ? items : fallbackItems;
  if (nextVisibleItems.length) lastVisibleItems.current = nextVisibleItems;
  const visibleItems = nextVisibleItems.length ? nextVisibleItems : lastVisibleItems.current;
  if (!visibleItems.length) return <section className="content-ticker" aria-label={isAr ? "شريط معلومات من الدليل" : "Guide information ticker"}><div className="content-ticker-label"><Radio size={15} /> <span>{isAr ? "من الدليل" : "From the guide"}</span></div><span className="ticker-empty">{isAr ? "لا توجد معلومات مطابقة للنص المحدد" : "No matching text"}</span>{isAdmin && <button type="button" className="ticker-settings-button" onClick={() => setControlsOpen((value) => !value)}><Settings2 size={15} /></button>}</section>;
  const repeatedItems = [...visibleItems, ...visibleItems];
  const filterOptions: Array<[Filter, string, string]> = [["all", "الكل", "All"], ["finance", "المالية", "Finance"], ["operations", "العمليات", "Operations"], ["hr", "الموارد البشرية", "HR"], ["programme", "البرامج", "Programme"], ["donor", "المانحون", "Donors"], ["logistics", "اللوجستيات", "Logistics"]];
  return <section className="content-ticker" dir={isAr ? "rtl" : "ltr"} aria-label={isAr ? "شريط معلومات من الدليل" : "Guide information ticker"}>
    <div className="content-ticker-label"><Radio size={15} /> <span>{isAr ? "من الدليل" : "From the guide"}</span></div>
    <div className="content-ticker-window" aria-live="off"><div className={`content-ticker-track ${isAr ? "arabic" : ""} ${direction === "reverse" ? "reverse" : ""} ${paused ? "paused" : ""}`} style={{ animationDuration: `${speed}s`, animationDirection: direction === "reverse" ? "reverse" : "normal" }}>{repeatedItems.map((item, index) => <span key={`${index}-${item}`} aria-hidden={index >= items.length}>{item}</span>)}</div></div>
    {isAdmin && <div ref={controlsRef} className="ticker-admin"><button type="button" className="ticker-settings-button" onClick={() => setControlsOpen((value) => !value)} aria-expanded={controlsOpen} aria-label={isAr ? "إعدادات شريط الأخبار" : "Ticker settings"}><Settings2 size={15} /></button>{controlsOpen && <div className="ticker-controls" role="dialog" aria-label={isAr ? "إعدادات شريط الأخبار" : "Ticker controls"}><b>{isAr ? "معاينة إعدادات الشريط" : "Live ticker preview"}</b><label>{isAr ? "السرعة (كلما زاد الرقم أصبح أبطأ)" : "Speed (higher is slower)"}<input type="range" min="300" max="2000" step="50" value={speed} onChange={(event) => setSpeed(Number(event.target.value))} /><small>{speed}s · {isAr ? "تطبيق فوري" : "Applied live"}</small></label><label>{isAr ? "الاتجاه" : "Direction"}<select value={direction} onChange={(event) => setDirection(event.target.value as Direction)}><option value="forward">{isAr ? "من اليمين إلى اليسار" : "Forward"}</option><option value="reverse">{isAr ? "من اليسار إلى اليمين" : "Reverse"}</option></select></label><label>{isAr ? "الفئة" : "Category"}<select value={filter} onChange={(event) => setFilter(event.target.value as Filter)}>{filterOptions.map(([value, ar, en]) => <option key={value} value={value}>{isAr ? ar : en}</option>)}</select></label><label>{isAr ? "نص أو مصطلح محدد" : "Specific text or term"}<input value={textFilter} onChange={(event) => setTextFilter(event.target.value)} placeholder={isAr ? "مثال: PO أو الموازنة" : "e.g. PO or budget"} /></label><button type="button" className="ticker-pause-button" onClick={() => setPaused((value) => !value)}>{paused ? <Play size={14} /> : <Pause size={14} />} {paused ? (isAr ? "تشغيل" : "Resume") : (isAr ? "إيقاف مؤقت" : "Pause")}</button></div>}</div>}
  </section>;
}
